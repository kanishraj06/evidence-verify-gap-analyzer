import streamlit as st
from typing import Dict, Any, List
from backend.app.models.schemas import EvidenceRecord, ResumeStructured, JobDescriptionStructured
from backend.app.evidence_intelligence.maturity_engine import EvidenceMaturityEngine
from backend.app.evidence_intelligence.gap_classifier import GapClassifier
from backend.app.evidence_intelligence.contradiction_engine import ContradictionDetectionEngine
from backend.app.evidence_intelligence.skill_graph import SkillDependencyGraph

maturity_engine = EvidenceMaturityEngine()
gap_classifier = GapClassifier()
contradiction_engine = ContradictionDetectionEngine()
skill_graph = SkillDependencyGraph()

def render_evidence_intelligence_panel(
    resume: ResumeStructured,
    jd: JobDescriptionStructured,
    evidence_map: Dict[str, EvidenceRecord],
    matched_pairs: List[Any]
):
    st.markdown("### 🧠 Advanced Evidence Intelligence Insights")
    st.caption("Deep engineering maturity tiers, gap classification taxonomies, and contradiction audits.")

    # Contradictions Alert Card
    contradictions = contradiction_engine.audit_resume_contradictions(resume, evidence_map)
    if contradictions:
        for c in contradictions:
            st.warning(f"⚠️ **{c['category']} ({c['severity']} Severity):** {c['details']}")
    else:
        st.success("✓ Zero architectural contradictions or timeline discrepancies detected in resume.")

    st.markdown("---")

    col_mat, col_gap = st.columns(2)
    with col_mat:
        st.markdown("#### 🏆 Implementation Maturity Tiers")
        maturity_list = [maturity_engine.assess_maturity(rec) for rec in evidence_map.values()]
        for m in maturity_list[:6]:
            with st.container():
                st.markdown(f"**{m['skill']}:** `{m['maturity_level']}`")
                st.caption(f"*{m['description']}*")

    with col_gap:
        st.markdown("#### 🏷️ Granular Gap Taxonomies")
        gaps_classified = [
            gap_classifier.classify_gap(req.skill_name, rec, req)
            for req, rec in matched_pairs
            if rec.status.value not in ["STRONGLY SUPPORTED", "SUPPORTED"]
        ]
        if gaps_classified:
            for g in gaps_classified[:5]:
                st.markdown(f"**{g['skill']}:** <span class='badge badge-simulated'>{g['classification_type']}</span>", unsafe_allow_html=True)
                st.caption(f"Strategy: {g['remediation_strategy']}")
        else:
            st.info("No active gaps to classify.")
