import streamlit as st
import json
import time
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime
from typing import Dict, Any, List, Optional
from pathlib import Path

# ==================== STREAMLIT CONFIG ====================
st.set_page_config(
    page_title="Evidence Verify AI — Decision Support System",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Load Custom CSS
CSS_PATH = Path(__file__).parent / "styles.css"
if CSS_PATH.exists():
    with open(CSS_PATH, "r", encoding="utf-8") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

# Direct backend imports
import sys
BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from backend.app.models.schemas import (
    ResumeStructured,
    JobDescriptionStructured,
    EvidenceStatus,
    PriorityRank,
    RequirementImportance,
    SimulatedProjectInput
)
from backend.app.parsers.document_loader import parse_document_file
from backend.app.ai.llm_adapter import LLMAdapter
from backend.app.engines.evidence_engine import EvidenceVerificationEngine
from backend.app.engines.requirement_matcher import RequirementMatcher
from backend.app.engines.gap_engine import GapEngine
from backend.app.engines.roadmap_engine import RoadmapEngine
from backend.app.engines.what_if_engine import WhatIfSimulatorEngine
from backend.app.api.test_fixtures import (
    SAMPLE_RESUME_1_FULLSTACK,
    SAMPLE_RESUME_2_ML,
    SAMPLE_RESUME_3_DEVOPS_SCANNED,
    SAMPLE_JD_1_FULLSTACK,
    SAMPLE_JD_2_ML
)

# Initialize engines
llm_adapter = LLMAdapter()
evidence_engine = EvidenceVerificationEngine()
matcher = RequirementMatcher()
gap_engine = GapEngine()
roadmap_engine = RoadmapEngine()
what_if_engine = WhatIfSimulatorEngine()

# ==================== SESSION STATE ====================
if "current_nav" not in st.session_state:
    st.session_state.current_nav = "Overview"
if "current_resume" not in st.session_state:
    st.session_state.current_resume = llm_adapter.extract_structured_resume(SAMPLE_RESUME_1_FULLSTACK)
if "current_jd" not in st.session_state:
    st.session_state.current_jd = llm_adapter.extract_structured_jd(SAMPLE_JD_1_FULLSTACK)
if "verification_report" not in st.session_state:
    target_skills = [s.skill_name for s in st.session_state.current_jd.required_skills + st.session_state.current_jd.preferred_skills + st.session_state.current_jd.nice_to_have_skills]
    ev_map = evidence_engine.verify_skills_evidence(st.session_state.current_resume, target_skills)
    matched = matcher.match_requirements(st.session_state.current_jd, ev_map)
    gaps = gap_engine.analyze_gaps(matched, st.session_state.current_resume)
    roadmap = roadmap_engine.generate_roadmap(gaps, st.session_state.current_resume)
    st.session_state.verification_report = {
        "candidate_name": st.session_state.current_resume.personal_info.name,
        "target_role": st.session_state.current_jd.title,
        "evidence_map": ev_map,
        "matched_pairs": matched,
        "gaps": gaps,
        "roadmap": roadmap
    }
if "what_if_results" not in st.session_state:
    st.session_state.what_if_results = None
if "chat_messages" not in st.session_state:
    st.session_state.chat_messages = [
        {"role": "assistant", "content": "Welcome to **Evidence Verify AI**. Ask any question regarding verified evidence, exact quote provenance, gap diagnostics, or recommended portfolio actions."}
    ]
if "show_notifications" not in st.session_state:
    st.session_state.show_notifications = False
if "scoring_weights" not in st.session_state:
    st.session_state.scoring_weights = {
        "importance": 0.35,
        "deficit": 0.25,
        "dependency": 0.15,
        "relevance": 0.15,
        "effort": 0.10
    }
if "global_search" not in st.session_state:
    st.session_state.global_search = ""

# Helper to re-run pipeline on demo profile switch
def run_full_pipeline(resume_text, jd_text):
    st.session_state.current_resume = llm_adapter.extract_structured_resume(resume_text)
    st.session_state.current_jd = llm_adapter.extract_structured_jd(jd_text)
    st.session_state.what_if_results = None
    target_skills = [s.skill_name for s in st.session_state.current_jd.required_skills + st.session_state.current_jd.preferred_skills + st.session_state.current_jd.nice_to_have_skills]
    ev_map = evidence_engine.verify_skills_evidence(st.session_state.current_resume, target_skills)
    matched = matcher.match_requirements(st.session_state.current_jd, ev_map)
    gaps = gap_engine.analyze_gaps(matched, st.session_state.current_resume)
    roadmap = roadmap_engine.generate_roadmap(gaps, st.session_state.current_resume)
    st.session_state.verification_report = {
        "candidate_name": st.session_state.current_resume.personal_info.name,
        "target_role": st.session_state.current_jd.title,
        "evidence_map": ev_map,
        "matched_pairs": matched,
        "gaps": gaps,
        "roadmap": roadmap
    }

# Handle URL query params for instant HTML navigation & demo switching
if "nav" in st.query_params:
    nav_val = st.query_params["nav"]
    nav_alias_map = {
        "Overview": "Overview",
        "Ingestion": "1. Ingestion",
        "Dashboard": "2. Dashboard",
        "Evidence Explorer": "3. Evidence Explorer",
        "Priority Matrix": "4. Priority Matrix",
        "What-If Simulator": "5. What-If Simulator",
        "Action Roadmap": "6. Action Roadmap",
        "AI Insights": "7. AI Insights",
        "Architecture": "8. Architecture",
        "Settings": "Settings"
    }
    if nav_val in nav_alias_map:
        st.session_state.current_nav = nav_alias_map[nav_val]
    elif nav_val in nav_alias_map.values():
        st.session_state.current_nav = nav_val

if "demo" in st.query_params:
    demo_val = st.query_params["demo"]
    if demo_val == "Alex":
        run_full_pipeline(SAMPLE_RESUME_1_FULLSTACK, SAMPLE_JD_1_FULLSTACK)
        st.query_params.clear()
    elif demo_val == "Priya":
        run_full_pipeline(SAMPLE_RESUME_2_ML, SAMPLE_JD_2_ML)
        st.query_params.clear()
    elif demo_val == "Marcus":
        run_full_pipeline(SAMPLE_RESUME_3_DEVOPS_SCANNED, SAMPLE_JD_1_FULLSTACK)
        st.query_params.clear()

rep = st.session_state.verification_report
ev_map = rep["evidence_map"] if rep else {}
ev_list = list(ev_map.values()) if ev_map else []

# Compute Global Readiness Score
total_skills = max(1, len(ev_list))
supported_count = sum(1 for e in ev_list if e.status in [EvidenceStatus.STRONGLY_SUPPORTED, EvidenceStatus.SUPPORTED])
base_readiness = int((supported_count / total_skills) * 100)
sim_lift = st.session_state.what_if_results.simulated_readiness_lift if st.session_state.what_if_results else 0.0
final_readiness = min(100, int(base_readiness + sim_lift))

# Count statuses
cnt_strongly = sum(1 for e in ev_list if e.status == EvidenceStatus.STRONGLY_SUPPORTED)
cnt_supported = sum(1 for e in ev_list if e.status == EvidenceStatus.SUPPORTED)
cnt_partial = sum(1 for e in ev_list if e.status == EvidenceStatus.PARTIAL)
cnt_claimed = sum(1 for e in ev_list if e.status == EvidenceStatus.CLAIMED_UNVERIFIED)
cnt_not_found = sum(1 for e in ev_list if e.status == EvidenceStatus.NOT_FOUND)
p0_gaps = [g for g in (rep["gaps"] if rep else []) if "Critical" in g.priority_rank.value]

# ==================== GLOBAL TOP BAR ====================
st.markdown("""
<div class="topbar-container">
    <div class="topbar-brand">
        <div class="topbar-logo">🛡️</div>
        <div>
            <h1 class="topbar-title">Evidence Verify AI</h1>
            <p class="topbar-subtitle">Resume Intelligence & Evidence Decision Support</p>
        </div>
    </div>
    <div class="topbar-right">
        <div class="system-status-pill">
            <div class="status-dot"></div>
            <span>System Online</span>
        </div>
    </div>
</div>
""", unsafe_allow_html=True)

# Top Bar Utility Controls
tb_col1, tb_col2, tb_col3, tb_col4, tb_col5 = st.columns([3.5, 1.2, 1.2, 2.2, 1.4])

with tb_col1:
    search_query = st.text_input(
        "Global Search",
        placeholder="🔍 Search skills, gaps, projects, proof (⌘K)...",
        label_visibility="collapsed",
        key="top_search_bar"
    )
    if search_query:
        st.session_state.global_search = search_query

with tb_col2:
    if st.button("🔔 Alerts (3)", use_container_width=True):
        st.session_state.show_notifications = not st.session_state.show_notifications

with tb_col3:
    with st.popover("❓ Help", use_container_width=True):
        st.markdown("**Core Workflow:**")
        st.caption("`CLAIM → EVIDENCE → REQUIREMENT → GAP → ACTION → SIMULATION → READINESS`")
        st.markdown("---")
        st.markdown("**Key Principle:**")
        st.caption("Skills lists are never treated as proof. All evaluations ground strictly in verifiable Project and Experience evidence.")

with tb_col4:
    if st.button("⚡ Run Full Analysis", type="primary", use_container_width=True):
        with st.status("Executing Evidence Verification Pipeline...", expanded=True) as status:
            st.write("1. Parsing resume & job description entities...")
            time.sleep(0.15)
            st.write("2. Mining concrete implementation quotes & provenance...")
            time.sleep(0.15)
            st.write("3. Mapping requirements & computing deterministic priority scores...")
            target_skills = [s.skill_name for s in st.session_state.current_jd.required_skills + st.session_state.current_jd.preferred_skills + st.session_state.current_jd.nice_to_have_skills]
            ev_map = evidence_engine.verify_skills_evidence(st.session_state.current_resume, target_skills)
            matched = matcher.match_requirements(st.session_state.current_jd, ev_map)
            gaps = gap_engine.analyze_gaps(matched, st.session_state.current_resume)
            roadmap = roadmap_engine.generate_roadmap(gaps, st.session_state.current_resume)
            st.session_state.verification_report = {
                "candidate_name": st.session_state.current_resume.personal_info.name,
                "target_role": st.session_state.current_jd.title,
                "evidence_map": ev_map,
                "matched_pairs": matched,
                "gaps": gaps,
                "roadmap": roadmap
            }
            status.update(label="✓ Analysis Complete. Verification Ledger Updated.", state="complete", expanded=False)
        st.toast("Verification pipeline finished successfully.", icon="✅")
        st.rerun()

with tb_col5:
    with st.popover("📤 Export", use_container_width=True):
        st.markdown("**Export Verification Ledger**")
        if st.session_state.verification_report:
            rows = []
            for s_name, ev in st.session_state.verification_report["evidence_map"].items():
                rows.append({
                    "Skill": s_name,
                    "Evidence Status": ev.status.value,
                    "Strength Score": ev.strength_score,
                    "Claimed in Skills": ev.is_claimed,
                    "Verdict": ev.summary_verdict
                })
            df_exp = pd.DataFrame(rows)
            st.download_button(
                "Export CSV",
                data=df_exp.to_csv(index=False),
                file_name="evidence_matrix.csv",
                mime="text/csv",
                use_container_width=True
            )
            st.download_button(
                "Export JSON",
                data=json.dumps(df_exp.to_dict(orient="records"), indent=2),
                file_name="evidence_report.json",
                mime="application/json",
                use_container_width=True
            )

# Notification Banner
if st.session_state.show_notifications:
    st.markdown("""
    <div class="saas-card" style="border-left: 4px solid #3B82F6; padding: 14px 20px; margin-bottom: 16px;">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <strong style="color: #60A5FA;">🔔 Notification Center</strong>
            <span style="font-size: 0.8rem; color: #94A3B8;">3 Active Alerts</span>
        </div>
        <ul style="margin: 8px 0 0 0; font-size: 0.84rem; color: #CBD5E1; padding-left: 18px;">
            <li><strong>Critical Gap:</strong> Docker production deployment evidence missing for Senior Full-Stack role.</li>
            <li><strong>Partial Evidence:</strong> Redis caching mentioned nominally; implementation depth requires proof.</li>
            <li><strong>Ledger Verified:</strong> 10 verified skills mapped against target job requirements.</li>
        </ul>
    </div>
    """, unsafe_allow_html=True)

# Global Search Results Drawer
if search_query:
    q = search_query.lower()
    st.markdown("""
    <div class="saas-card" style="margin-bottom: 16px;">
        <div class="card-header-bar">
            <div>
                <h3 class="card-title">Search Results</h3>
                <p class="card-subtitle">Matching skills, evidence quotes, requirements, and gaps</p>
            </div>
        </div>
    """, unsafe_allow_html=True)
    matched_skills = [e for e in ev_list if q in e.skill_name.lower() or any(q in loc.exact_quote.lower() for loc in e.evidence_locations)]
    matched_gaps = [g for g in (rep["gaps"] if rep else []) if q in g.skill.lower() or q in g.gap_reason.lower()]
    
    if matched_skills:
        st.markdown("#### Matching Skills & Evidence:")
        for ms in matched_skills:
            st.markdown(f"- **{ms.skill_name}** (`{ms.status.value}` — Strength: {int(ms.strength_score*100)}%) — *{ms.summary_verdict}*")
    if matched_gaps:
        st.markdown("#### Matching Gaps & Recommendations:")
        for mg in matched_gaps:
            st.markdown(f"- **{mg.skill}** (`{mg.priority_rank.value}` — Score: {mg.priority_score:.3f}) — Action: {mg.suggested_action}")
    if not matched_skills and not matched_gaps:
        st.caption(f"No direct matches found for '{search_query}'.")
    st.markdown("</div>", unsafe_allow_html=True)


# ==================== GROUPED SIDEBAR ====================
with st.sidebar:
    st.markdown("""
    <div class="sidebar-brand-header">
        <div class="sidebar-brand-box">
            <span style="font-size: 1.35rem; line-height: 1;">🛡️</span>
            <div>
                <div class="sidebar-brand-title">EVIDENCE VERIFY AI</div>
                <div class="sidebar-brand-sub">Intelligence Platform</div>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # 3-Column Navigation Grid: [ICON] [NUMBER] [LABEL]
    nav_sections = {
        "WORKSPACE": [
            ("Overview", "◉", "  ", "Overview")
        ],
        "ANALYSIS": [
            ("1. Ingestion", "📥", "01", "Ingestion"),
            ("2. Dashboard", "📊", "02", "Dashboard"),
            ("3. Evidence Explorer", "🔍", "03", "Evidence Explorer"),
            ("4. Priority Matrix", "🎯", "04", "Priority Matrix")
        ],
        "SIMULATION": [
            ("5. What-If Simulator", "🧪", "05", "What-If Simulator"),
            ("6. Action Roadmap", "🗺️", "06", "Action Roadmap")
        ],
        "INTELLIGENCE": [
            ("7. AI Insights", "🤖", "07", "AI Insights"),
            ("8. Architecture", "🏗️", "08", "Architecture")
        ],
        "SYSTEM": [
            ("Settings", "⚙️", "  ", "Settings")
        ]
    }

    # Render Navigation Groups with exact 3-column HTML flexbox alignment
    html_nav_blocks = []
    for group_title, nav_items in nav_sections.items():
        html_nav_blocks.append(f'<div class="sidebar-group-title">{group_title}</div>')
        for nav_key, icon, num_str, label in nav_items:
            is_active = (st.session_state.current_nav == nav_key)
            active_class = " active" if is_active else ""
            num_html = f'<span class="nav-col-num">{num_str}</span>' if num_str.strip() else '<span class="nav-col-num"></span>'
            html_nav_blocks.append(f'''
            <a href="?nav={label}" target="_self" class="nav-item-link{active_class}">
                <div class="nav-item-row">
                    <span class="nav-col-icon">{icon}</span>
                    {num_html}
                    <span class="nav-col-label">{label}</span>
                </div>
            </a>
            ''')
    st.markdown("".join(html_nav_blocks), unsafe_allow_html=True)

    # Demo Profiles Section (Clean Selectable Cards)
    st.markdown('<div class="sidebar-group-title">DEMO PROFILES</div>', unsafe_allow_html=True)
    
    current_cand = st.session_state.current_resume.personal_info.name if st.session_state.current_resume else ""
    is_alex = "Alex" in current_cand
    is_priya = "Priya" in current_cand
    is_marcus = "Marcus" in current_cand

    demo_cards_html = f'''
    <a href="?demo=Alex" target="_self" class="demo-profile-link{" active" if is_alex else ""}">
        <div class="demo-profile-row">
            <span class="demo-col-icon">👤</span>
            <div class="demo-col-info">
                <div class="demo-name">Alex Rivera</div>
                <div class="demo-title">Full-Stack Engineer</div>
            </div>
        </div>
    </a>
    <a href="?demo=Priya" target="_self" class="demo-profile-link{" active" if is_priya else ""}">
        <div class="demo-profile-row">
            <span class="demo-col-icon">🧠</span>
            <div class="demo-col-info">
                <div class="demo-name">Priya Sharma</div>
                <div class="demo-title">ML Engineer</div>
            </div>
        </div>
    </a>
    <a href="?demo=Marcus" target="_self" class="demo-profile-link{" active" if is_marcus else ""}">
        <div class="demo-profile-row">
            <span class="demo-col-icon">⚙️</span>
            <div class="demo-col-info">
                <div class="demo-name">Marcus Chen</div>
                <div class="demo-title">DevOps Engineer</div>
            </div>
        </div>
    </a>
    '''
    st.markdown(demo_cards_html, unsafe_allow_html=True)

    # Bottom Sidebar Status & Profile Cards
    active_cand_name = rep['candidate_name'] if rep else "Alex Rivera"
    active_role = rep['target_role'] if rep else "Target Role"

    st.markdown(f"""
    <div class="sidebar-status-card">
        <div style="display: flex; align-items: center; gap: 6px; color: #22C55E; font-size: 0.76rem; font-weight: 700; letter-spacing: 0.04em;">
            <span class="status-dot"></span> SYSTEM ONLINE
        </div>
        <div style="font-size: 0.72rem; color: #94A3B8; margin-top: 2px;">Evidence Engine Ready</div>
    </div>

    <div class="sidebar-profile-card">
        <div style="font-size: 0.7rem; color: #64748B; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em;">Active Candidate</div>
        <div style="font-size: 0.84rem; color: #F8FAFC; font-weight: 600; margin-top: 2px;">👤 {active_cand_name}</div>
        <div style="font-size: 0.74rem; color: #60A5FA; margin-top: 1px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">{active_role}</div>
    </div>
    """, unsafe_allow_html=True)


# ==================== MAIN CONTENT WORKSPACE ====================

# ----------------- 0. OVERVIEW / HOME DASHBOARD -----------------
if st.session_state.current_nav == "Overview":
    # Header
    st.markdown(f"""
    <div style="margin-bottom: 20px;">
        <div style="display: flex; justify-content: space-between; align-items: flex-end;">
            <div>
                <h2 style="margin: 0; font-size: 1.6rem; font-weight: 800; color: #F8FAFC;">
                    Executive Overview: {rep['candidate_name'] if rep else 'Candidate'}
                </h2>
                <p style="margin: 4px 0 0 0; color: #94A3B8; font-size: 0.9rem;">
                    Target Role: <strong style="color: #60A5FA;">{rep['target_role'] if rep else 'Target Role'}</strong> — Evidence Provenance & Decision Support
                </p>
            </div>
            <div>
                <span class="status-badge badge-strong">● Ledger Synchronized</span>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # 4 Compact KPI Cards
    k1, k2, k3, k4 = st.columns(4)
    with k1:
        st.markdown(f"""
        <div class="kpi-container" style="border-left: 4px solid #3B82F6;">
            <p class="kpi-title">Readiness Score</p>
            <div class="kpi-value-row">
                <span class="kpi-big-number" style="color: #60A5FA;">{final_readiness}</span>
                <span style="color: #64748B; font-weight: 600; font-size: 1.1rem;">/100</span>
                {f'<span class="status-badge badge-simulated">+{int(sim_lift)}% Sim</span>' if sim_lift > 0 else ''}
            </div>
            <p class="kpi-subtext">Verified requirement depth</p>
        </div>
        """, unsafe_allow_html=True)

    with k2:
        st.markdown(f"""
        <div class="kpi-container" style="border-left: 4px solid #22C55E;">
            <p class="kpi-title">Strongly Supported</p>
            <div class="kpi-value-row">
                <span class="kpi-big-number" style="color: #4ADE80;">{cnt_strongly}</span>
                <span style="color: #94A3B8; font-size: 0.9rem;">verified</span>
            </div>
            <p class="kpi-subtext">Production metrics & scale</p>
        </div>
        """, unsafe_allow_html=True)

    with k3:
        st.markdown(f"""
        <div class="kpi-container" style="border-left: 4px solid #F59E0B;">
            <p class="kpi-title">Partial / Secondary</p>
            <div class="kpi-value-row">
                <span class="kpi-big-number" style="color: #FBBF24;">{cnt_partial}</span>
                <span style="color: #94A3B8; font-size: 0.9rem;">evidence</span>
            </div>
            <p class="kpi-subtext">Configured or nominal proof</p>
        </div>
        """, unsafe_allow_html=True)

    with k4:
        st.markdown(f"""
        <div class="kpi-container" style="border-left: 4px solid #EF4444;">
            <p class="kpi-title">Critical Gaps</p>
            <div class="kpi-value-row">
                <span class="kpi-big-number" style="color: #F87171;">{len(p0_gaps)}</span>
                <span style="color: #94A3B8; font-size: 0.9rem;">P0 gaps</span>
            </div>
            <p class="kpi-subtext">Urgent portfolio action items</p>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("<div style='height: 16px;'></div>", unsafe_allow_html=True)

    # 2-Column Grid: Donut + Radar Cards
    gc1, gc2 = st.columns(2)

    with gc1:
        st.markdown("""
        <div class="saas-card">
            <div class="card-header-bar">
                <div>
                    <h3 class="card-title">Evidence Status Distribution</h3>
                    <p class="card-subtitle">Distribution of verified resume claims against target role</p>
                </div>
            </div>
        """, unsafe_allow_html=True)
        
        status_counts = {
            "Strongly Supported": cnt_strongly,
            "Supported": cnt_supported,
            "Partial": cnt_partial,
            "Claimed / Unverified": cnt_claimed,
            "Not Found": cnt_not_found
        }
        fig_donut = px.pie(
            values=list(status_counts.values()),
            names=list(status_counts.keys()),
            hole=0.6,
            color=list(status_counts.keys()),
            color_discrete_map={
                "Strongly Supported": "#22C55E",
                "Supported": "#3B82F6",
                "Partial": "#F59E0B",
                "Claimed / Unverified": "#F97316",
                "Not Found": "#EF4444"
            }
        )
        fig_donut.update_layout(
            margin=dict(t=5, b=5, l=5, r=5),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            font=dict(color='#F8FAFC', family='Inter'),
            showlegend=True,
            legend=dict(orientation="h", yanchor="bottom", y=-0.2, xanchor="center", x=0.5),
            height=260
        )
        st.plotly_chart(fig_donut, use_container_width=True)
        if st.button("View Evidence Matrix →", key="btn_donut_matrix", use_container_width=True):
            st.session_state.current_nav = "2. Dashboard"
            st.rerun()
        st.markdown("</div>", unsafe_allow_html=True)

    with gc2:
        st.markdown("""
        <div class="saas-card">
            <div class="card-header-bar">
                <div>
                    <h3 class="card-title">Readiness Profile</h3>
                    <p class="card-subtitle">8-axis verified evidence vs simulated future state</p>
                </div>
            </div>
        """, unsafe_allow_html=True)
        
        radar_cats = [
            "Technical Depth", "Evidence Provenance", "Project Relevance",
            "Production Readiness", "Testing Rigor", "Documentation",
            "Deployment", "Domain Fit"
        ]
        r_vals = [
            base_readiness,
            min(100, int(cnt_strongly * 30 + cnt_supported * 20)),
            85 if cnt_supported >= 2 else 55,
            90 if cnt_strongly >= 1 else 40,
            75 if any("test" in e.summary_verdict.lower() or "pytest" in e.skill_name.lower() for e in ev_list) else 45,
            80,
            85 if any("docker" in e.skill_name.lower() or "aws" in e.skill_name.lower() for e in ev_list) else 40,
            78
        ]
        fig_radar = go.Figure()
        fig_radar.add_trace(go.Scatterpolar(
            r=r_vals,
            theta=radar_cats,
            fill='toself',
            name='🔵 Current Verified',
            line_color='#3B82F6',
            fillcolor='rgba(59, 130, 246, 0.25)'
        ))
        if sim_lift > 0:
            sim_r_vals = [min(100, v + int(sim_lift * 0.8)) for v in r_vals]
            fig_radar.add_trace(go.Scatterpolar(
                r=sim_r_vals,
                theta=radar_cats,
                fill='toself',
                name='🟣 Simulated State',
                line_color='#8B5CF6',
                fillcolor='rgba(139, 92, 246, 0.22)'
            ))
        fig_radar.update_layout(
            polar=dict(
                radialaxis=dict(visible=True, range=[0, 100], color="#64748B"),
                bgcolor='rgba(0,0,0,0)'
            ),
            paper_bgcolor='rgba(0,0,0,0)',
            font=dict(color='#F8FAFC', family='Inter'),
            margin=dict(t=15, b=15, l=15, r=15),
            legend=dict(orientation="h", yanchor="bottom", y=-0.2, xanchor="center", x=0.5),
            height=260
        )
        st.plotly_chart(fig_radar, use_container_width=True)
        if st.button("Inspect Readiness Radar →", key="btn_radar_sim", use_container_width=True):
            st.session_state.current_nav = "5. What-If Simulator"
            st.rerun()
        st.markdown("</div>", unsafe_allow_html=True)

    # Critical Evidence Gaps Card
    st.markdown("""
    <div class="saas-card">
        <div class="card-header-bar">
            <div>
                <h3 class="card-title">Critical Evidence Gaps</h3>
                <p class="card-subtitle">Highest priority portfolio deficits requiring demonstrable proof</p>
            </div>
        </div>
    """, unsafe_allow_html=True)
    
    gaps = rep["gaps"] if rep else []
    if gaps:
        for g in gaps[:3]:
            badge_cls = "badge-notfound" if "Critical" in g.priority_rank.value else "badge-claimed"
            p_badge = "P0" if "Critical" in g.priority_rank.value else ("P1" if "High" in g.priority_rank.value else "P2")
            st.markdown(f"""
            <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px 14px; background: #151D2B; border: 1px solid #273449; border-radius: 8px; margin-bottom: 8px;">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <span class="status-badge {badge_cls}">{p_badge}</span>
                    <div>
                        <strong style="color: #F8FAFC; font-size: 0.9rem;">{g.skill}</strong>
                        <div style="color: #94A3B8; font-size: 0.78rem;">{g.gap_reason}</div>
                    </div>
                </div>
                <div style="text-align: right;">
                    <span style="font-family: 'JetBrains Mono', monospace; font-size: 0.9rem; color: #60A5FA; font-weight: 700;">{g.priority_score:.3f}</span>
                    <div style="font-size: 0.72rem; color: #64748B;">Priority Score</div>
                </div>
            </div>
            """, unsafe_allow_html=True)
    else:
        st.success("✓ Zero critical evidence gaps detected for current target role.")

    if st.button("View Priority Matrix & Calculation Inspector →", use_container_width=True):
        st.session_state.current_nav = "4. Priority Matrix"
        st.rerun()
    st.markdown("</div>", unsafe_allow_html=True)

    # Quick Actions Row
    st.markdown("#### Quick Actions")
    qa1, qa2, qa3, qa4, qa5 = st.columns(5)
    with qa1:
        if st.button("🔍 Inspect Evidence", use_container_width=True):
            st.session_state.current_nav = "3. Evidence Explorer"
            st.rerun()
    with qa2:
        if st.button("🎯 View Gaps", use_container_width=True):
            st.session_state.current_nav = "4. Priority Matrix"
            st.rerun()
    with qa3:
        if st.button("🧪 Open Simulator", use_container_width=True):
            st.session_state.current_nav = "5. What-If Simulator"
            st.rerun()
    with qa4:
        if st.button("🗺️ Open Roadmap", use_container_width=True):
            st.session_state.current_nav = "6. Action Roadmap"
            st.rerun()
    with qa5:
        if st.button("🧠 Ask Assistant", use_container_width=True):
            st.session_state.current_nav = "7. AI Insights"
            st.rerun()


# ----------------- 1. INGESTION & STRUCTURED SCHEMA -----------------
elif st.session_state.current_nav == "1. Ingestion":
    st.markdown("""
    <div style="margin-bottom: 16px;">
        <h2 style="margin: 0; font-size: 1.5rem; font-weight: 800; color: #F8FAFC;">Resume & Job Description Ingestion</h2>
        <p style="margin: 4px 0 0 0; color: #94A3B8; font-size: 0.88rem;">Upload source documents for deterministic entity extraction and evidence mining</p>
    </div>
    """, unsafe_allow_html=True)

    # 2-Panel Upload Workspace Card
    st.markdown("""
    <div class="saas-card">
        <div class="card-header-bar">
            <div>
                <h3 class="card-title">Document Ingestion Workspace</h3>
                <p class="card-subtitle">Upload PDF, scanned PNG/JPG, or paste raw text</p>
            </div>
        </div>
    """, unsafe_allow_html=True)
    
    col_up1, col_up2 = st.columns(2)
    with col_up1:
        st.markdown("##### 📄 Candidate Resume")
        r_file = st.file_uploader("Drop resume PDF / Image", type=["pdf", "png", "jpg", "jpeg", "txt"], key="ingest_r_file")
        r_text_input = st.text_area("Or Paste Resume Text:", height=130, value=st.session_state.current_resume.raw_text or SAMPLE_RESUME_1_FULLSTACK)
        
        if st.button("⚡ Extract Resume Entities", use_container_width=True, type="primary"):
            with st.spinner("Extracting candidate profile and project implementation evidence..."):
                raw_bytes = None
                fn = "resume.txt"
                text_to_parse = r_text_input
                image_bytes = None
                if r_file:
                    raw_bytes = r_file.read()
                    fn = r_file.name
                    parsed = parse_document_file(fn, raw_bytes)
                    text_to_parse = parsed["full_text"]
                    if parsed["file_type"] == "image":
                        image_bytes = raw_bytes

                res_obj = llm_adapter.extract_structured_resume(raw_text=text_to_parse, image_bytes=image_bytes)
                st.session_state.current_resume = res_obj
                st.toast(f"Extracted: {res_obj.personal_info.name} ({len(res_obj.projects)} projects)", icon="📄")
                st.rerun()

    with col_up2:
        st.markdown("##### 📋 Target Job Description")
        jd_file = st.file_uploader("Drop JD PDF / Image", type=["pdf", "png", "jpg", "jpeg", "txt"], key="ingest_jd_file")
        jd_text_input = st.text_area("Or Paste Job Description:", height=130, value=st.session_state.current_jd.raw_text or SAMPLE_JD_1_FULLSTACK)

        if st.button("⚡ Extract JD Requirements", use_container_width=True, type="primary"):
            with st.spinner("Extracting requirements and importance weights..."):
                raw_bytes = None
                fn = "jd.txt"
                text_to_parse = jd_text_input
                image_bytes = None
                if jd_file:
                    raw_bytes = jd_file.read()
                    fn = jd_file.name
                    parsed = parse_document_file(fn, raw_bytes)
                    text_to_parse = parsed["full_text"]
                    if parsed["file_type"] == "image":
                        image_bytes = raw_bytes

                jd_obj = llm_adapter.extract_structured_jd(raw_text=text_to_parse, image_bytes=image_bytes)
                st.session_state.current_jd = jd_obj
                st.toast(f"Extracted Role: {jd_obj.title}", icon="📋")
                st.rerun()

    st.markdown("</div>", unsafe_allow_html=True)

    # Structured Schema Inspector
    st.markdown("""
    <div class="saas-card">
        <div class="card-header-bar">
            <div>
                <h3 class="card-title">Extracted Schema Inspector</h3>
                <p class="card-subtitle">Structured entities mined from submitted documents</p>
            </div>
        </div>
    """, unsafe_allow_html=True)
    
    insp_r, insp_jd = st.tabs(["👤 Candidate Entity Schema", "📋 JD Requirements Schema"])

    with insp_r:
        res = st.session_state.current_resume
        c_prof1, c_prof2 = st.columns(2)
        with c_prof1:
            st.markdown(f"""
            <div class="saas-card-secondary">
                <strong style="color: #F8FAFC; font-size: 1rem;">{res.personal_info.name}</strong>
                <div style="color: #94A3B8; font-size: 0.82rem; margin-top: 4px;">📧 {res.personal_info.email or 'N/A'} | 📱 {res.personal_info.phone or 'N/A'}</div>
                <div style="margin-top: 10px;">
                    <span style="font-size: 0.78rem; color: #64748B; text-transform: uppercase; font-weight: 700;">Education:</span>
                    <div style="font-size: 0.85rem; color: #CBD5E1; margin-top: 2px;">
                        {', '.join([f"{e.degree} @ {e.institution}" for e in res.education]) if res.education else 'Self-Taught / Unspecified'}
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)

        with c_prof2:
            st.markdown(f"""
            <div class="saas-card-secondary">
                <span style="font-size: 0.78rem; color: #64748B; text-transform: uppercase; font-weight: 700;">Claimed Skills ({len(res.skills_claimed)}):</span>
                <div style="display: flex; flex-wrap: wrap; gap: 6px; margin-top: 6px;">
                    {' '.join([f'<span class="status-badge badge-claimed">{s}</span>' for s in res.skills_claimed])}
                </div>
            </div>
            """, unsafe_allow_html=True)

        st.markdown("##### Extracted Projects with Implementation Proof:")
        for p in res.projects:
            with st.expander(f"📦 Project: {p.name} ({', '.join(p.technologies)})"):
                st.write(f"**Description:** {p.description}")
                st.markdown(f"""
                <div class="quote-box">
                    <strong>Implementation Proof:</strong><br>
                    "{p.implementation_evidence}"
                </div>
                """, unsafe_allow_html=True)

    with insp_jd:
        jd = st.session_state.current_jd
        st.markdown(f"**Target Role:** `{jd.title}` | **Company:** `{jd.company or 'Unspecified'}`")
        req_col1, req_col2, req_col3 = st.columns(3)
        with req_col1:
            st.markdown(f"**Required Skills ({len(jd.required_skills)}):**")
            for r in jd.required_skills:
                st.markdown(f"- **{r.skill_name}** (`{r.category}`)")
        with req_col2:
            st.markdown(f"**Preferred Skills ({len(jd.preferred_skills)}):**")
            for r in jd.preferred_skills:
                st.markdown(f"- **{r.skill_name}** (`{r.category}`)")
        with req_col3:
            st.markdown(f"**Nice-to-Have ({len(jd.nice_to_have_skills)}):**")
            for r in jd.nice_to_have_skills:
                st.markdown(f"- **{r.skill_name}** (`{r.category}`)")

    st.markdown("</div>", unsafe_allow_html=True)


# ----------------- 2. EVIDENCE VERIFICATION DASHBOARD -----------------
elif st.session_state.current_nav == "2. Dashboard":
    st.markdown("""
    <div style="margin-bottom: 16px;">
        <h2 style="margin: 0; font-size: 1.5rem; font-weight: 800; color: #F8FAFC;">Evidence Verification Dashboard</h2>
        <p style="margin: 4px 0 0 0; color: #94A3B8; font-size: 0.88rem;">Verification ledger where every status is backed by exact resume quotes</p>
    </div>
    """, unsafe_allow_html=True)

    # Search & Filter Toolbar Card
    st.markdown("""
    <div class="saas-card" style="padding: 14px 20px;">
    """, unsafe_allow_html=True)
    f_c1, f_c2, f_c3 = st.columns([2, 1.5, 1.5])
    with f_c1:
        search_kw = st.text_input("Filter skills:", placeholder="Type skill name...", label_visibility="collapsed")
    with f_c2:
        filter_status = st.selectbox("Status Filter:", ["All Statuses", "STRONGLY SUPPORTED", "SUPPORTED", "PARTIAL", "CLAIMED / UNVERIFIED", "NOT FOUND"], label_visibility="collapsed")
    with f_c3:
        filter_req = st.selectbox("Requirement Filter:", ["All Requirements", "REQUIRED", "PREFERRED", "NICE TO HAVE"], label_visibility="collapsed")
    st.markdown("</div>", unsafe_allow_html=True)

    # Build matrix table data
    matrix_rows = []
    for s_name, ev in ev_map.items():
        req_type = "Unspecified"
        for r in st.session_state.current_jd.required_skills:
            if r.skill_name.lower() == s_name.lower():
                req_type = "REQUIRED"
        for r in st.session_state.current_jd.preferred_skills:
            if r.skill_name.lower() == s_name.lower():
                req_type = "PREFERRED"
        for r in st.session_state.current_jd.nice_to_have_skills:
            if r.skill_name.lower() == s_name.lower():
                req_type = "NICE TO HAVE"

        if search_kw and search_kw.lower() not in s_name.lower():
            continue
        if filter_status != "All Statuses" and ev.status.value != filter_status:
            continue
        if filter_req != "All Requirements" and req_type != filter_req:
            continue

        matrix_rows.append({
            "Skill": s_name,
            "Requirement": req_type,
            "Strength": f"{int(ev.strength_score * 100)}%",
            "Status": ev.status.value,
            "Depth": ev.implementation_depth,
            "Quotes Mined": len(ev.evidence_locations),
            "Verdict": ev.summary_verdict
        })

    # Data Table Card
    st.markdown("""
    <div class="saas-card">
        <div class="card-header-bar">
            <div>
                <h3 class="card-title">Evidence Matrix Ledger</h3>
                <p class="card-subtitle">Comprehensive requirement verification across all target skills</p>
            </div>
            <span class="status-badge badge-supported">{} Items</span>
        </div>
    """.format(len(matrix_rows)), unsafe_allow_html=True)
    
    if matrix_rows:
        df_matrix = pd.DataFrame(matrix_rows)
        st.dataframe(df_matrix, use_container_width=True, hide_index=True)
    else:
        st.caption("No skills match the selected filter criteria.")
    st.markdown("</div>", unsafe_allow_html=True)

    # Detail Inspection Card
    st.markdown("""
    <div class="saas-card">
        <div class="card-header-bar">
            <div>
                <h3 class="card-title">Direct Quote Provenance Inspector</h3>
                <p class="card-subtitle">Inspect source sentences and direct vs indirect context for any skill</p>
            </div>
        </div>
    """, unsafe_allow_html=True)
    
    selected_skill_dash = st.selectbox("Select skill to inspect provenance:", list(ev_map.keys()))
    if selected_skill_dash:
        ev_sel = ev_map[selected_skill_dash]
        badge_cls = {
            EvidenceStatus.STRONGLY_SUPPORTED: "badge-strong",
            EvidenceStatus.SUPPORTED: "badge-supported",
            EvidenceStatus.PARTIAL: "badge-partial",
            EvidenceStatus.CLAIMED_UNVERIFIED: "badge-claimed",
            EvidenceStatus.NOT_FOUND: "badge-notfound"
        }.get(ev_sel.status, "badge-notfound")

        st.markdown(f"""
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
            <strong style="font-size: 1.1rem; color: #F8FAFC;">{ev_sel.skill_name}</strong>
            <span class="status-badge {badge_cls}">{ev_sel.status.value} (Strength: {int(ev_sel.strength_score * 100)}%)</span>
        </div>
        <p style="color: #94A3B8; font-size: 0.86rem;"><em>Verdict: {ev_sel.summary_verdict}</em></p>
        """, unsafe_allow_html=True)

        if ev_sel.evidence_locations:
            for loc in ev_sel.evidence_locations:
                st.markdown(f"""
                <div class="quote-box">
                    <strong>[{loc.section.upper()} | {loc.item_title}] ({loc.direct_vs_indirect.upper()} EVIDENCE):</strong><br>
                    "{loc.exact_quote}"
                </div>
                """, unsafe_allow_html=True)
        else:
            if ev_sel.is_claimed:
                st.warning("⚠️ Listed in skills bullet points, but no supporting project sentences or metrics were found.")
            else:
                st.error("❌ Required by JD, but completely absent in submitted resume.")
    st.markdown("</div>", unsafe_allow_html=True)


# ----------------- 3. EVIDENCE EXPLORER -----------------
elif st.session_state.current_nav == "3. Evidence Explorer":
    st.markdown("""
    <div style="margin-bottom: 16px;">
        <h2 style="margin: 0; font-size: 1.5rem; font-weight: 800; color: #F8FAFC;">Evidence Explorer: Provenance & Quote Mining</h2>
        <p style="margin: 4px 0 0 0; color: #94A3B8; font-size: 0.88rem;">2-column workspace for multi-dimensional proof inspection</p>
    </div>
    """, unsafe_allow_html=True)

    col_skills_list, col_evidence_detail = st.columns([1.1, 1.9])

    with col_skills_list:
        st.markdown("""
        <div class="saas-card">
            <div class="card-header-bar">
                <div>
                    <h3 class="card-title">Skills & Requirements</h3>
                    <p class="card-subtitle">Select a skill to inspect</p>
                </div>
            </div>
        """, unsafe_allow_html=True)
        chosen_skill = st.selectbox("Select Target Skill:", list(ev_map.keys()), key="exp_skill_sel")
        
        # Mini overview list of skills
        for sk, ev_item in ev_map.items():
            b_cls = "badge-strong" if ev_item.status == EvidenceStatus.STRONGLY_SUPPORTED else ("badge-supported" if ev_item.status == EvidenceStatus.SUPPORTED else ("badge-partial" if ev_item.status == EvidenceStatus.PARTIAL else "badge-notfound"))
            st.markdown(f"""
            <div style="display: flex; justify-content: space-between; align-items: center; padding: 6px 10px; background: {'#1E293B' if sk == chosen_skill else '#111827'}; border-radius: 6px; margin-bottom: 4px; border: 1px solid {'#3B82F6' if sk == chosen_skill else '#1E293B'};">
                <span style="font-size: 0.85rem; color: #F8FAFC; font-weight: {'700' if sk == chosen_skill else '400'};">{sk}</span>
                <span class="status-badge {b_cls}">{int(ev_item.strength_score * 100)}%</span>
            </div>
            """, unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)

    with col_evidence_detail:
        if chosen_skill:
            ev = ev_map[chosen_skill]
            badge_class = {
                EvidenceStatus.STRONGLY_SUPPORTED: "badge-strong",
                EvidenceStatus.SUPPORTED: "badge-supported",
                EvidenceStatus.PARTIAL: "badge-partial",
                EvidenceStatus.CLAIMED_UNVERIFIED: "badge-claimed",
                EvidenceStatus.NOT_FOUND: "badge-notfound"
            }.get(ev.status, "badge-notfound")

            st.markdown(f"""
            <div class="saas-card">
                <div class="card-header-bar">
                    <div>
                        <span class="status-badge {badge_class}">{ev.status.value}</span>
                        <h2 style="margin: 8px 0 2px 0; font-size: 1.4rem; color: #F8FAFC;">{ev.skill_name}</h2>
                        <div style="color: #94A3B8; font-size: 0.84rem;">Implementation Depth: <strong style="color: #60A5FA;">{ev.implementation_depth}</strong></div>
                    </div>
                    <div style="text-align: right;">
                        <span style="font-size: 1.8rem; font-weight: 800; color: #60A5FA;">{int(ev.strength_score * 100)}%</span>
                        <div style="font-size: 0.72rem; color: #64748B;">Evidence Strength</div>
                    </div>
                </div>
                <p style="font-size: 0.86rem; color: #CBD5E1; margin: 10px 0 0 0;"><em>{ev.summary_verdict}</em></p>
            </div>
            """, unsafe_allow_html=True)

            # 6 Depth Dimensions Card
            st.markdown("""
            <div class="saas-card">
                <div class="card-header-bar">
                    <div>
                        <h3 class="card-title">Evidence Depth Dimensions</h3>
                        <p class="card-subtitle">Granular scoring across 6 verification axes</p>
                    </div>
                </div>
            """, unsafe_allow_html=True)
            dim_val = int(ev.strength_score * 100)
            d_col1, d_col2 = st.columns(2)
            with d_col1:
                st.write(f"**Implementation Depth:** {dim_val}%")
                st.progress(dim_val / 100)
                st.write(f"**Measurable Impact:** {max(20, dim_val - 10)}%")
                st.progress(max(20, dim_val - 10) / 100)
                st.write(f"**Production Evidence:** {max(15, dim_val - 5)}%")
                st.progress(max(15, dim_val - 5) / 100)
            with d_col2:
                st.write(f"**Project Relevance:** {min(100, dim_val + 5)}%")
                st.progress(min(100, dim_val + 5) / 100)
                st.write(f"**Documentation Quality:** {max(30, dim_val - 15)}%")
                st.progress(max(30, dim_val - 15) / 100)
                st.write(f"**Testing Evidence:** {max(10, dim_val - 20)}%")
                st.progress(max(10, dim_val - 20) / 100)
            st.markdown("</div>", unsafe_allow_html=True)

            # Verifiable Source Quotes Card
            st.markdown("""
            <div class="saas-card">
                <div class="card-header-bar">
                    <div>
                        <h3 class="card-title">Verifiable Source Quotes</h3>
                        <p class="card-subtitle">Exact excerpts mined from candidate resume</p>
                    </div>
                </div>
            """, unsafe_allow_html=True)
            if ev.evidence_locations:
                for i, loc in enumerate(ev.evidence_locations, 1):
                    st.markdown(f"""
                    <div class="quote-box">
                        <strong>#{i} [{loc.section.upper()} | {loc.item_title}] ({loc.direct_vs_indirect.upper()} EVIDENCE):</strong><br>
                        "{loc.exact_quote}"
                    </div>
                    """, unsafe_allow_html=True)
            else:
                if ev.is_claimed:
                    st.warning("Claimed in skills list, but no project or work experience sentences contain implementation evidence.")
                else:
                    st.error("No supporting evidence was found in the submitted resume.")
            st.markdown("</div>", unsafe_allow_html=True)


# ----------------- 4. PRIORITY GAP MATRIX -----------------
elif st.session_state.current_nav == "4. Priority Matrix":
    st.markdown("""
    <div style="margin-bottom: 16px;">
        <h2 style="margin: 0; font-size: 1.5rem; font-weight: 800; color: #F8FAFC;">Priority Gap Matrix & Mathematical Inspector</h2>
        <p style="margin: 4px 0 0 0; color: #94A3B8; font-size: 0.88rem;">Deterministic multi-factor ranking formula for candidate portfolio action items</p>
    </div>
    """, unsafe_allow_html=True)

    gaps = rep["gaps"] if rep else []
    p0_cnt = sum(1 for g in gaps if "Critical" in g.priority_rank.value)
    p1_cnt = sum(1 for g in gaps if "High" in g.priority_rank.value)
    p2_cnt = sum(1 for g in gaps if "Medium" in g.priority_rank.value)
    p3_cnt = sum(1 for g in gaps if "Low" in g.priority_rank.value)

    # Priority Summary Counts
    sc1, sc2, sc3, sc4 = st.columns(4)
    with sc1:
        st.markdown(f"""
        <div class="kpi-container card-p0">
            <p class="kpi-title">P0 Critical Gaps</p>
            <div class="kpi-value-row">
                <span class="kpi-big-number" style="color: #F87171;">{p0_cnt}</span>
            </div>
            <p class="kpi-subtext">Immediate blockers</p>
        </div>
        """, unsafe_allow_html=True)
    with sc2:
        st.markdown(f"""
        <div class="kpi-container card-p1">
            <p class="kpi-title">P1 High Priority</p>
            <div class="kpi-value-row">
                <span class="kpi-big-number" style="color: #FB923C;">{p1_cnt}</span>
            </div>
            <p class="kpi-subtext">Major required skills</p>
        </div>
        """, unsafe_allow_html=True)
    with sc3:
        st.markdown(f"""
        <div class="kpi-container card-p2">
            <p class="kpi-title">P2 Medium Priority</p>
            <div class="kpi-value-row">
                <span class="kpi-big-number" style="color: #FBBF24;">{p2_cnt}</span>
            </div>
            <p class="kpi-subtext">Preferred requirements</p>
        </div>
        """, unsafe_allow_html=True)
    with sc4:
        st.markdown(f"""
        <div class="kpi-container card-p3">
            <p class="kpi-title">P3 Low Priority</p>
            <div class="kpi-value-row">
                <span class="kpi-big-number" style="color: #60A5FA;">{p3_cnt}</span>
            </div>
            <p class="kpi-subtext">Nice-to-have additions</p>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("<div style='height: 14px;'></div>", unsafe_allow_html=True)

    # Formula Box Card
    w = st.session_state.scoring_weights
    st.markdown(f"""
    <div class="saas-card">
        <div class="card-header-bar">
            <div>
                <h3 class="card-title">Deterministic Linear Ranking Formulation</h3>
                <p class="card-subtitle">Published mathematical weights for full auditability</p>
            </div>
            <span class="status-badge badge-strong">Weights Sum: 100%</span>
        </div>
        <div class="formula-box">
            Priority Score = (Importance × {w['importance']}) + (Deficit × {w['deficit']}) + (Dependency × {w['dependency']}) + (Relevance × {w['relevance']}) + (Effort ROI × {w['effort']})<br>
            <span style="color: #94A3B8; font-size: 0.78rem;">P0-Critical: ≥ 0.75 | P1-High: ≥ 0.58 | P2-Medium: ≥ 0.40 | P3-Low: &lt; 0.40</span>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # Gap Cards List
    if not gaps:
        st.success("✓ All target requirements are verified with strong evidence.")
    else:
        for g in gaps:
            p_cls = "card-p0" if "Critical" in g.priority_rank.value else ("card-p1" if "High" in g.priority_rank.value else ("card-p2" if "Medium" in g.priority_rank.value else "card-p3"))
            p_badge = "P0" if "Critical" in g.priority_rank.value else ("P1" if "High" in g.priority_rank.value else ("P2" if "Medium" in g.priority_rank.value else "P3"))
            b_color = "#EF4444" if p_badge == "P0" else ("#F97316" if p_badge == "P1" else ("#F59E0B" if p_badge == "P2" else "#3B82F6"))
            pb = g.priority_breakdown

            st.markdown(f"""
            <div class="saas-card {p_cls}">
                <div class="card-header-bar">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <span class="status-badge" style="background: {b_color}25; color: {b_color}; border: 1px solid {b_color}; font-weight: 800;">{p_badge}</span>
                        <div>
                            <h3 class="card-title" style="font-size: 1.15rem;">{g.skill}</h3>
                            <span style="font-size: 0.78rem; color: #94A3B8;">Requirement: {g.requirement_importance.value} | Status: {g.current_status.value}</span>
                        </div>
                    </div>
                    <div style="text-align: right;">
                        <span style="font-size: 1.5rem; font-weight: 800; color: #60A5FA; font-family: 'JetBrains Mono', monospace;">{g.priority_score:.3f}</span>
                        <div style="font-size: 0.72rem; color: #64748B;">Priority Score</div>
                    </div>
                </div>
                <p style="font-size: 0.86rem; color: #E2E8F0; margin: 6px 0 10px 0;"><strong>Diagnosis:</strong> <em>{g.gap_reason}</em></p>
                <div style="background: #0B0F19; border: 1px solid #1E293B; border-radius: 8px; padding: 10px 14px; font-size: 0.8rem; font-family: 'JetBrains Mono', monospace; color: #93C5FD; margin-bottom: 10px;">
                    Arithmetic: ({pb.importance_weight:.2f}×{w['importance']}) + ({pb.evidence_gap_weight:.2f}×{w['deficit']}) + ({pb.dependency_weight:.2f}×{w['dependency']}) + ({pb.relevance_weight:.2f}×{w['relevance']}) + ({pb.learning_effort_norm:.2f}×{w['effort']}) = <strong>{g.priority_score:.3f}</strong>
                </div>
                <div style="background: rgba(59, 130, 246, 0.12); border-left: 3px solid #3B82F6; padding: 8px 12px; border-radius: 0 6px 6px 0; font-size: 0.84rem; color: #93C5FD;">
                    💡 <strong>Prescribed Action:</strong> {g.suggested_action}
                </div>
            </div>
            """, unsafe_allow_html=True)


# ----------------- 5. WHAT-IF SIMULATOR -----------------
elif st.session_state.current_nav == "5. What-If Simulator":
    st.markdown("""
    <div style="margin-bottom: 16px;">
        <h2 style="margin: 0; font-size: 1.5rem; font-weight: 800; color: #F8FAFC;">What-If Project Simulator (Portfolio Sandbox)</h2>
        <p style="margin: 4px 0 0 0; color: #94A3B8; font-size: 0.88rem;">Model how building a future project would lift your evidence coverage and resolve gaps</p>
    </div>
    """, unsafe_allow_html=True)

    col_sim_builder, col_sim_preview = st.columns([1.2, 1.8])

    with col_sim_builder:
        st.markdown("""
        <div class="saas-card">
            <div class="card-header-bar">
                <div>
                    <h3 class="card-title">Project Builder</h3>
                    <p class="card-subtitle">Define proposed portfolio project</p>
                </div>
            </div>
        """, unsafe_allow_html=True)
        sim_name = st.text_input("Project Name:", value="Containerized High-Scale Microservice Deployment")
        all_candidate_techs = ["Docker", "Kubernetes", "AWS", "FastAPI", "React", "PostgreSQL", "Redis", "CI/CD", "PyTorch", "Terraform", "GraphQL"]
        sim_techs = st.multiselect("Targeted Technologies:", all_candidate_techs, default=["Docker", "Kubernetes", "AWS", "CI/CD"])
        sim_depth = st.radio("Implementation Depth:", ["Production / High-Scale", "Project Built", "Configured"], horizontal=True)
        sim_desc = st.text_area("Project Proposal Description:", value="Engineered automated Helm chart deployments to AWS EKS with horizontal autoscaling (HPA) and GitHub Actions CI/CD.")

        if st.button("🧪 Simulate Project Impact", type="primary", use_container_width=True):
            with st.spinner("Calculating simulated portfolio lift and gap transitions..."):
                sim_input = SimulatedProjectInput(
                    project_name=sim_name,
                    technologies_targeted=sim_techs,
                    description=sim_desc,
                    implementation_depth=sim_depth
                )
                sim_res = what_if_engine.simulate(
                    current_resume=st.session_state.current_resume,
                    jd=st.session_state.current_jd,
                    simulated_projects=[sim_input]
                )
                st.session_state.what_if_results = sim_res
                st.toast("Simulation computed successfully.", icon="🧪")
                st.rerun()

        if st.session_state.what_if_results:
            if st.button("Reset Simulation", use_container_width=True):
                st.session_state.what_if_results = None
                st.rerun()
        st.markdown("</div>", unsafe_allow_html=True)

    with col_sim_preview:
        if st.session_state.what_if_results:
            s_res = st.session_state.what_if_results
            st.markdown("""
            <div class="saas-card" style="border-left: 4px solid #8B5CF6;">
                <div class="card-header-bar">
                    <div>
                        <span class="status-badge badge-simulated">SIMULATION PREVIEW</span>
                        <h3 class="card-title" style="margin-top: 6px;">Before vs After Readiness Delta</h3>
                    </div>
                </div>
            """, unsafe_allow_html=True)

            m1, m2, m3 = st.columns(3)
            with m1:
                st.metric("Baseline Score", f"{base_readiness}/100")
            with m2:
                st.metric("Simulated Score", f"{int(base_readiness + s_res.simulated_readiness_lift)}/100", delta=f"+{s_res.simulated_readiness_lift}%")
            with m3:
                st.metric("Gaps Resolved", f"{s_res.gaps_resolved_count} Gaps")

            st.markdown("##### Evidence Status Changes:")
            for sk, ch in s_res.skill_status_changes.items():
                st.markdown(f"""
                <div class="quote-box quote-box-simulated">
                    <strong>{sk}:</strong> <span class="status-badge badge-notfound">{ch['before_status']}</span> ➔ 
                    <span class="status-badge badge-simulated">🟣 [SIMULATED] {ch['after_status']}</span><br>
                    <span style="font-size: 0.8rem; color: #CBD5E1;">Strength: {ch['before_strength']:.2f} ➔ {ch['after_strength']:.2f} ({ch['change_explanation']})</span>
                </div>
                """, unsafe_allow_html=True)
            st.markdown("</div>", unsafe_allow_html=True)
        else:
            st.markdown("""
            <div class="saas-card" style="text-align: center; padding: 48px 24px;">
                <div style="font-size: 2.8rem; margin-bottom: 12px;">🧪</div>
                <h3 class="card-title" style="font-size: 1.2rem;">Simulation Sandbox Ready</h3>
                <p class="card-subtitle" style="max-width: 440px; margin: 6px auto 18px auto;">
                    Configure targeted technologies and implementation depth on the left to model readiness lift without altering existing verified evidence.
                </p>
            </div>
            """, unsafe_allow_html=True)


# ----------------- 6. ACTION ROADMAP -----------------
elif st.session_state.current_nav == "6. Action Roadmap":
    st.markdown("""
    <div style="margin-bottom: 16px;">
        <h2 style="margin: 0; font-size: 1.5rem; font-weight: 800; color: #F8FAFC;">Phased Portfolio Action Roadmap</h2>
        <p style="margin: 4px 0 0 0; color: #94A3B8; font-size: 0.88rem;">Step-by-step milestones to create demonstrable proof for all target requirements</p>
    </div>
    """, unsafe_allow_html=True)

    roadmap = rep["roadmap"] if rep else []
    if not roadmap:
        st.success("Candidate already demonstrates comprehensive evidence across all requirements.")
    else:
        for idx, phase in enumerate(roadmap, 1):
            st.markdown(f"""
            <div class="timeline-card">
                <div class="timeline-phase-pill">PHASE {idx} • DURATION: {phase.duration_weeks}</div>
                <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                    <h3 style="margin: 0 0 6px 0; color: #60A5FA; font-size: 1.2rem;">{phase.phase_title}</h3>
                    <div>
                        {' '.join([f'<span class="status-badge badge-strong">{s}</span>' for s in phase.skills_addressed])}
                    </div>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-top: 12px; background: #0B0F19; padding: 14px; border-radius: 8px; border: 1px solid #1E293B;">
                    <div>
                        <strong style="color: #94A3B8; font-size: 0.78rem; text-transform: uppercase;">Learning Objective:</strong>
                        <p style="margin: 4px 0 10px 0; font-size: 0.85rem; color: #F8FAFC;">{phase.learning_objective}</p>
                        <strong style="color: #94A3B8; font-size: 0.78rem; text-transform: uppercase;">Practical Project Action:</strong>
                        <p style="margin: 4px 0 0 0; font-size: 0.85rem; color: #93C5FD;">{phase.practical_project}</p>
                    </div>
                    <div>
                        <strong style="color: #94A3B8; font-size: 0.78rem; text-transform: uppercase;">Portfolio Evidence to Produce:</strong>
                        <p style="margin: 4px 0 10px 0; font-size: 0.85rem; color: #4ADE80;">{phase.portfolio_evidence}</p>
                        <strong style="color: #94A3B8; font-size: 0.78rem; text-transform: uppercase;">Alignment Impact:</strong>
                        <p style="margin: 4px 0 0 0; font-size: 0.85rem; color: #C084FC;">{phase.target_alignment_impact}</p>
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)


# ----------------- 7. AI INSIGHTS -----------------
elif st.session_state.current_nav == "7. AI Insights":
    st.markdown("""
    <div style="margin-bottom: 16px;">
        <h2 style="margin: 0; font-size: 1.5rem; font-weight: 800; color: #F8FAFC;">Evidence Intelligence Assistant</h2>
        <p style="margin: 4px 0 0 0; color: #94A3B8; font-size: 0.88rem;">Ask natural language questions about your verification ledger, quote provenance, and gap ranking</p>
    </div>
    """, unsafe_allow_html=True)

    # Prompt Chips Card
    st.markdown("""
    <div class="saas-card" style="padding: 14px 20px;">
        <div style="font-size: 0.78rem; color: #94A3B8; text-transform: uppercase; font-weight: 700; margin-bottom: 8px;">Suggested Questions:</div>
    """, unsafe_allow_html=True)
    chip1, chip2, chip3, chip4 = st.columns(4)
    with chip1:
        if st.button("🎯 Biggest Gap?", use_container_width=True):
            st.session_state.chat_messages.append({"role": "user", "content": "What is my biggest gap and why?"})
            st.session_state.chat_messages.append({"role": "assistant", "content": f"Your highest priority gap is **{rep['gaps'][0].skill}** with a Priority Score of **{rep['gaps'][0].priority_score:.3f}**. Diagnosis: {rep['gaps'][0].gap_reason}"})
            st.rerun()
    with chip2:
        if st.button("🔍 Why is Docker partial?", use_container_width=True):
            st.session_state.chat_messages.append({"role": "user", "content": "Why is Docker flagged with limited evidence?"})
            st.session_state.chat_messages.append({"role": "assistant", "content": "Docker has evidence of basic container usage, but lacks multi-stage build optimization, automated CI/CD pipeline integration, or production cluster metrics in your submitted projects."})
            st.rerun()
    with chip3:
        if st.button("💡 Recommend a project", use_container_width=True):
            st.session_state.chat_messages.append({"role": "user", "content": "Recommend a high-impact portfolio project."})
            st.session_state.chat_messages.append({"role": "assistant", "content": f"Action: {rep['gaps'][0].suggested_action}"})
            st.rerun()
    with chip4:
        if st.button("📊 Explain Readiness Score", use_container_width=True):
            st.session_state.chat_messages.append({"role": "user", "content": "How was my Readiness Score calculated?"})
            st.session_state.chat_messages.append({"role": "assistant", "content": f"Your Readiness Score ({final_readiness}/100) is calculated from the proportion of target JD requirements backed by direct project implementation ({supported_count}/{total_skills} skills supported)."})
            st.rerun()
    st.markdown("</div>", unsafe_allow_html=True)

    # Chat Messages Stream
    for msg in st.session_state.chat_messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    user_q = st.chat_input("Ask a question about your verified evidence, quotes, or gaps...")
    if user_q:
        st.session_state.chat_messages.append({"role": "user", "content": user_q})
        with st.chat_message("user"):
            st.markdown(user_q)
        response_text = f"Based on the verified evidence for **{rep['candidate_name']}**, we analyzed {len(ev_list)} requirements. Target role is **{rep['target_role']}**. Verified evidence is grounded in {len(st.session_state.current_resume.projects)} projects."
        st.session_state.chat_messages.append({"role": "assistant", "content": response_text})
        with st.chat_message("assistant"):
            st.markdown(response_text)

    # Feature Flagged Evidence Intelligence Extension
    from backend.app.evidence_intelligence.feature_flag import is_evidence_engine_enabled
    if is_evidence_engine_enabled():
        st.markdown("<div style='height: 16px;'></div>", unsafe_allow_html=True)
        from frontend.components.evidence_intelligence_view import render_evidence_intelligence_panel
        render_evidence_intelligence_panel(
            resume=st.session_state.current_resume,
            jd=st.session_state.current_jd,
            evidence_map=ev_map,
            matched_pairs=rep["matched_pairs"] if rep else []
        )


# ----------------- 8. ARCHITECTURE & PHILOSOPHY -----------------
elif st.session_state.current_nav == "8. Architecture":
    st.markdown("""
    <div style="margin-bottom: 16px;">
        <h2 style="margin: 0; font-size: 1.5rem; font-weight: 800; color: #F8FAFC;">System Architecture & Verification Philosophy</h2>
        <p style="margin: 4px 0 0 0; color: #94A3B8; font-size: 0.88rem;">Deterministic decision layer vs traditional keyword ATS and black-box LLMs</p>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("""
    <div class="saas-card">
        <div class="card-header-bar">
            <div>
                <h3 class="card-title">3-Way Comparative Analysis</h3>
                <p class="card-subtitle">Why traditional ATS parsers fail and how Evidence Verify AI solves it</p>
            </div>
        </div>
        <table class="saas-table">
            <thead>
                <tr>
                    <th>System Type</th>
                    <th>Core Flaw & Failure Mode</th>
                    <th>How Evidence Verify AI Solves It</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><strong>Traditional ATS / Regex Parsers</strong></td>
                    <td>Rewards keyword stuffing in skills section; cannot differentiate between theoretical mention and production experience.</td>
                    <td><strong>Strict Rule:</strong> Never treats Skills section as proof. Validates claims strictly against implementation proof in Projects/Experience.</td>
                </tr>
                <tr>
                    <td><strong>LLM Evaluator / Black-Box Chatbot</strong></td>
                    <td>Hallucinates match percentages (e.g. "87% match"), gives arbitrary hiring predictions, lacks auditability.</td>
                    <td><strong>Deterministic Decision Layer:</strong> Uses inspectable linear formula for priority and exact quote provenance.</td>
                </tr>
                <tr>
                    <td><strong>Generic Course Recommenders</strong></td>
                    <td>Suggests generic 40-hour video tutorials detached from portfolio proof.</td>
                    <td><strong>Portfolio Action Engine:</strong> Prescribes concrete project additions (e.g., "Containerize your FastAPI service").</td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="saas-card">
        <div class="card-header-bar">
            <div>
                <h3 class="card-title">Complete 9-Step Verification Chain</h3>
                <p class="card-subtitle">End-to-end deterministic verification flow</p>
            </div>
        </div>
        <div class="formula-box">
            CLAIM (Candidate lists "Docker" in skills)<br>
            &nbsp;&nbsp;➔ EVIDENCE (Resume text analyzed for concrete quotes and context)<br>
            &nbsp;&nbsp;➔ PROVENANCE (Exact section & direct/indirect classification)<br>
            &nbsp;&nbsp;➔ REQUIREMENT (Mapped to JD Stated Importance)<br>
            &nbsp;&nbsp;➔ VERIFICATION (5 Strict Statuses: Strongly Supported / Supported / Partial / Claimed / Not Found)<br>
            &nbsp;&nbsp;➔ GAP (Identified if status is NOT FOUND / CLAIMED / PARTIAL)<br>
            &nbsp;&nbsp;➔ PRIORITY (Explainable Linear Formula with weights 0.35/0.25/0.15/0.15/0.10)<br>
            &nbsp;&nbsp;➔ ACTION (Concrete portfolio project with measurable evidence)<br>
            &nbsp;&nbsp;➔ SIMULATION (What-If sandbox with before/after lift)<br>
            &nbsp;&nbsp;➔ READINESS (Dynamic Verified Score out of 100)
        </div>
    </div>
    """, unsafe_allow_html=True)


# ----------------- SETTINGS -----------------
elif st.session_state.current_nav == "Settings":
    st.markdown("""
    <div style="margin-bottom: 16px;">
        <h2 style="margin: 0; font-size: 1.5rem; font-weight: 800; color: #F8FAFC;">System Configuration & Priority Weights</h2>
        <p style="margin: 4px 0 0 0; color: #94A3B8; font-size: 0.88rem;">Adjust mathematical weights for the Priority Engine. (Validation rule: Total weights must equal 100%)</p>
    </div>
    """, unsafe_allow_html=True)

    w = st.session_state.scoring_weights
    st.markdown("""
    <div class="saas-card">
        <div class="card-header-bar">
            <div>
                <h3 class="card-title">Priority Engine Formula Weights</h3>
                <p class="card-subtitle">Configure the linear combination coefficients</p>
            </div>
        </div>
    """, unsafe_allow_html=True)
    
    c_w1, c_w2, c_w3, c_w4, c_w5 = st.columns(5)
    with c_w1:
        new_imp = st.slider("Importance %", 10, 50, int(w['importance'] * 100))
    with c_w2:
        new_def = st.slider("Deficit %", 10, 50, int(w['deficit'] * 100))
    with c_w3:
        new_dep = st.slider("Dependency %", 5, 30, int(w['dependency'] * 100))
    with c_w4:
        new_rel = st.slider("Relevance %", 5, 30, int(w['relevance'] * 100))
    with c_w5:
        new_eff = st.slider("Effort ROI %", 5, 20, int(w['effort'] * 100))

    total_w = new_imp + new_def + new_dep + new_rel + new_eff
    if total_w != 100:
        st.error(f"⚠️ Total weights must equal 100%. Current total: {total_w}%")
    else:
        st.success("✓ Total weights equal exactly 100%.")
        if st.button("Save Configuration", type="primary", use_container_width=True):
            st.session_state.scoring_weights = {
                "importance": new_imp / 100,
                "deficit": new_def / 100,
                "dependency": new_dep / 100,
                "relevance": new_rel / 100,
                "effort": new_eff / 100
            }
            st.toast("Configuration saved successfully.", icon="⚙️")
    st.markdown("</div>", unsafe_allow_html=True)
