# Technical Architecture & Research Justification

## 1. Literature Review & Research Grounding

### 1.1 The Failure Modes of Automated Resume Screening
Academic literature on automated recruitment screening (e.g., *Raghavan et al., 2020; Deshpande et al., 2020*) documents critical vulnerabilities in traditional automated resume parsing:
1. **Susceptibility to Keyword Stuffing**: Traditional boolean string matching and tf-idf heuristic models award high match scores to resumes containing uncontextualized skill keywords in "Skills" summary sections without verifying that those tools were applied in any project or work setting.
2. **Context Loss and False Equivalences**: Listing a tool (e.g., "Kubernetes") in a skills list often indicates basic familiarity or theoretical exposure, whereas real-world roles require orchestration, Helm chart templating, ingress configuration, and autoscaling.
3. **The Black-Box Hallucination Problem in LLM Scrapers**: As demonstrated by recent studies on Large Language Model evaluations (*Bender et al., 2021; Weidinger et al., 2022*), prompting generic LLMs to evaluate candidates leads to arbitrary numeric scoring (e.g., "83% match"), ungrounded hiring predictions, and inconsistent outputs across runs.

### 1.2 Our System Solution: Provenance-Anchored Evidence Verification
Our architecture solves these issues by decoupling semantic understanding from decision-making:
- **AI Layer (Semantic Extraction)**: Extracts structured entities (Projects, Roles, Concrete Implementation Quotes) using strict Pydantic JSON-schemas.
- **Evidence Verification Layer**: Evaluates claims only against concrete project narratives, implementation sentences, and verified credentials. It tracks exact quotes, section provenance, direct vs. indirect usage, and implementation depth.
- **Deterministic Decision Layer**: Matches requirements, calculates gap priorities using a transparent, published mathematical formula, and simulates portfolio interventions without LLM randomness.

---

## 2. Mathematical Priority Formula Justification

The Priority Engine uses a deterministic, multi-factor linear formulation:

$$P = w_1 \cdot I + w_2 \cdot D_{ev} + w_3 \cdot Dep + w_4 \cdot Rel + w_5 \cdot Eff$$

Where:
- $w_1 = 0.35$ (Requirement Importance: $REQUIRED=1.0, PREFERRED=0.65, NICE\_TO\_HAVE=0.35$)
- $w_2 = 0.25$ (Evidence Deficit: $D_{ev} = 1.0 - \text{EvidenceStrength}$)
- $w_3 = 0.15$ (Dependency Impact: Foundational blocking skills like Python, Docker, SQL receive higher weight)
- $w_4 = 0.15$ (Practical Relevance in target role stack)
- $w_5 = 0.10$ (Learning Effort ROI / Project Feasibility)

### Why this formula is defensible to judges:
1. **Explainable Trace**: Unlike neural embeddings or opaque LLM scores, every component can be inspected in real-time by the candidate or career coach.
2. **Monotonicity**: Increasing verified evidence strictly decreases gap priority; increasing requirement importance strictly increases gap priority.
3. **Actionability**: High priority directly maps to immediate portfolio projects with maximum alignment ROI.

---

## 3. Evidence Status Hierarchy & Provenance Schema

```mermaid
graph TD
    Resume[Submitted Resume] --> CheckSkills[Skills Section Claim?]
    CheckSkills -- Yes --> MineEvidence[Search Projects, Experience & Certs]
    CheckSkills -- No --> MineEvidence
    
    MineEvidence -- No Evidence & Claimed --> Claimed[CLAIMED / UNVERIFIED]
    MineEvidence -- No Evidence & Unclaimed --> NotFound[NOT FOUND]
    MineEvidence -- Peripheral Mention --> Partial[PARTIAL]
    MineEvidence -- Direct Project Implementation --> Supported[SUPPORTED]
    MineEvidence -- Production Scale / Metrics --> Strongly[STRONGLY SUPPORTED]
```
