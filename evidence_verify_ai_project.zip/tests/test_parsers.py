import pytest
from pathlib import Path
from backend.app.parsers.document_loader import parse_document_file

def test_pdf_parser_real_file():
    sample_pdf = Path(__file__).resolve().parent.parent / "backend" / "app" / "data" / "samples" / "resume_1_fullstack.pdf"
    if sample_pdf.exists():
        with open(sample_pdf, "rb") as f:
            pdf_bytes = f.read()
        res = parse_document_file("resume_1_fullstack.pdf", pdf_bytes)
        assert res["file_type"] == "pdf"
        assert "ALEX RIVERA" in res["full_text"]
        assert res["page_count"] >= 1
