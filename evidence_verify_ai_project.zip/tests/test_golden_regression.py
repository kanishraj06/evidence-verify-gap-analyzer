import json
import pytest
from pathlib import Path
from backend.app.ai.llm_adapter import LLMAdapter
from backend.app.engines.evidence_engine import EvidenceVerificationEngine
from backend.app.engines.requirement_matcher import RequirementMatcher
from backend.app.engines.gap_engine import GapEngine
from backend.app.engines.roadmap_engine import RoadmapEngine
from backend.app.engines.what_if_engine import WhatIfSimulatorEngine
from backend.app.models.schemas import SimulatedProjectInput
from backend.app.api.test_fixtures import (
    SAMPLE_RESUME_1_FULLSTACK,
    SAMPLE_RESUME_2_ML,
    SAMPLE_RESUME_3_DEVOPS_SCANNED,
    SAMPLE_JD_1_FULLSTACK,
    SAMPLE_JD_2_ML
)

GOLDEN_FILE = Path(__file__).resolve().parent / "golden" / "golden_snapshots.json"

def test_golden_snapshots_regression_guard():
    assert GOLDEN_FILE.exists(), "Golden snapshot file must exist"
    golden_data = json.loads(GOLDEN_FILE.read_text(encoding="utf-8"))

    llm = LLMAdapter()
    ev_engine = EvidenceVerificationEngine()
    matcher = RequirementMatcher()
    gap_engine = GapEngine()
    roadmap_engine = RoadmapEngine()
    what_if_engine = WhatIfSimulatorEngine()

    resumes = {
        "resume_1_fullstack": SAMPLE_RESUME_1_FULLSTACK,
        "resume_2_ml": SAMPLE_RESUME_2_ML,
        "resume_3_devops": SAMPLE_RESUME_3_DEVOPS_SCANNED
    }

    jds = {
        "jd_1_fullstack": SAMPLE_JD_1_FULLSTACK,
        "jd_2_ml": SAMPLE_JD_2_ML
    }

    for r_key, r_text in resumes.items():
        resume_obj = llm.extract_structured_resume(r_text)
        for j_key, j_text in jds.items():
            jd_obj = llm.extract_structured_jd(j_text)
            
            target_skills = [s.skill_name for s in jd_obj.required_skills + jd_obj.preferred_skills + jd_obj.nice_to_have_skills]
            ev_map = ev_engine.verify_skills_evidence(resume_obj, target_skills)
            matched = matcher.match_requirements(jd_obj, ev_map)
            gaps = gap_engine.analyze_gaps(matched, resume_obj)
            roadmap = roadmap_engine.generate_roadmap(gaps, resume_obj)

            sim_input = SimulatedProjectInput(
                project_name="Containerized Microservice",
                technologies_targeted=["Docker", "FastAPI"],
                description="Built and containerized FastAPI API with Docker.",
                implementation_depth="Project Built"
            )
            sim_res = what_if_engine.simulate(resume_obj, jd_obj, [sim_input])

            expected = golden_data[r_key][j_key]

            # Compare evidence statuses
            for s, status in expected["evidence_statuses"].items():
                assert ev_map[s].status.value == status, f"Mismatch in status for {s}"
                assert ev_map[s].strength_score == expected["evidence_strengths"][s], f"Mismatch in strength for {s}"

            # Compare gap priority scores
            for g in gaps:
                assert g.priority_score == expected["gap_priority_scores"][g.skill], f"Mismatch in gap score for {g.skill}"

            # Compare simulation results
            assert sim_res.simulated_readiness_lift == expected["sim_readiness_lift"]
            assert sim_res.gaps_resolved_count == expected["sim_gaps_resolved"]
