import json
from pathlib import Path
from backend.app.models.schemas import EvidenceStatus
from backend.app.ai.llm_adapter import LLMAdapter
from backend.app.engines.evidence_engine import EvidenceVerificationEngine
from backend.app.engines.requirement_matcher import RequirementMatcher
from backend.app.engines.gap_engine import GapEngine
from backend.app.engines.roadmap_engine import RoadmapEngine
from backend.app.engines.what_if_engine import WhatIfSimulatorEngine
from backend.app.models.schemas import SimulatedProjectInput
from backend.app.api.test_fixtures import (
    SAMPLE_RESUME_1_FULLSTACK,
    SAMPLE_RESUME_2_ML,
    SAMPLE_RESUME_3_DEVOPS_SCANNED,
    SAMPLE_JD_1_FULLSTACK,
    SAMPLE_JD_2_ML
)

GOLDEN_DIR = Path(__file__).resolve().parent / "golden"
GOLDEN_DIR.mkdir(parents=True, exist_ok=True)

llm = LLMAdapter()
ev_engine = EvidenceVerificationEngine()
matcher = RequirementMatcher()
gap_engine = GapEngine()
roadmap_engine = RoadmapEngine()
what_if_engine = WhatIfSimulatorEngine()

resumes = {
    "resume_1_fullstack": SAMPLE_RESUME_1_FULLSTACK,
    "resume_2_ml": SAMPLE_RESUME_2_ML,
    "resume_3_devops": SAMPLE_RESUME_3_DEVOPS_SCANNED
}

jds = {
    "jd_1_fullstack": SAMPLE_JD_1_FULLSTACK,
    "jd_2_ml": SAMPLE_JD_2_ML
}

golden_data = {}

for r_key, r_text in resumes.items():
    resume_obj = llm.extract_structured_resume(r_text)
    golden_data[r_key] = {}
    for j_key, j_text in jds.items():
        jd_obj = llm.extract_structured_jd(j_text)
        
        target_skills = [s.skill_name for s in jd_obj.required_skills + jd_obj.preferred_skills + jd_obj.nice_to_have_skills]
        ev_map = ev_engine.verify_skills_evidence(resume_obj, target_skills)
        matched = matcher.match_requirements(jd_obj, ev_map)
        gaps = gap_engine.analyze_gaps(matched, resume_obj)
        roadmap = roadmap_engine.generate_roadmap(gaps, resume_obj)

        # What if simulation
        sim_input = SimulatedProjectInput(
            project_name="Containerized Microservice",
            technologies_targeted=["Docker", "FastAPI"],
            description="Built and containerized FastAPI API with Docker.",
            implementation_depth="Project Built"
        )
        sim_res = what_if_engine.simulate(resume_obj, jd_obj, [sim_input])

        # Serialized record
        golden_data[r_key][j_key] = {
            "candidate_name": resume_obj.personal_info.name,
            "target_role": jd_obj.title,
            "evidence_statuses": {s: ev.status.value for s, ev in ev_map.items()},
            "evidence_strengths": {s: ev.strength_score for s, ev in ev_map.items()},
            "gap_priority_scores": {g.skill: g.priority_score for g in gaps},
            "gap_ranks": {g.skill: g.priority_rank.value for g in gaps},
            "roadmap_phase_count": len(roadmap),
            "sim_readiness_lift": sim_res.simulated_readiness_lift,
            "sim_gaps_resolved": sim_res.gaps_resolved_count
        }

output_file = GOLDEN_DIR / "golden_snapshots.json"
output_file.write_text(json.dumps(golden_data, indent=2), encoding="utf-8")
print(f"Successfully generated golden snapshots in: {output_file}")
