import pytest
from backend.app.models.schemas import (
    ResumeStructured,
    PersonalInfo,
    JobDescriptionStructured,
    SkillRequirement,
    RequirementImportance,
    SimulatedProjectInput,
    EvidenceStatus
)
from backend.app.engines.what_if_engine import WhatIfSimulatorEngine

def test_what_if_simulation_lift_and_separation():
    engine = WhatIfSimulatorEngine()
    
    resume = ResumeStructured(
        personal_info=PersonalInfo(name="Test Candidate"),
        skills_claimed=["Python", "FastAPI"],
        projects=[]
    )
    
    jd = JobDescriptionStructured(
        title="Backend Cloud Engineer",
        required_skills=[
            SkillRequirement(skill_name="FastAPI", importance=RequirementImportance.REQUIRED),
            SkillRequirement(skill_name="Docker", importance=RequirementImportance.REQUIRED)
        ]
    )

    sim_input = SimulatedProjectInput(
        project_name="Containerized Microservice",
        technologies_targeted=["Docker", "FastAPI"],
        description="Built and containerized FastAPI API with Docker.",
        implementation_depth="Project Built"
    )

    result = engine.simulate(
        current_resume=resume,
        jd=jd,
        simulated_projects=[sim_input]
    )

    assert result.gaps_resolved_count >= 1
    assert "Docker" in result.skill_status_changes
    assert result.skill_status_changes["Docker"]["before_status"] == EvidenceStatus.NOT_FOUND.value
    assert result.skill_status_changes["Docker"]["after_status"] == EvidenceStatus.SUPPORTED.value
    assert result.simulated_readiness_lift > 0
