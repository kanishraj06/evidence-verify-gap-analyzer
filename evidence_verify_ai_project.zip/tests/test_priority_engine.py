import pytest
from backend.app.models.schemas import (
    RequirementImportance,
    EvidenceStatus,
    PriorityRank
)
from backend.app.engines.priority_engine import PriorityEngine

def test_priority_engine_math_and_ranking():
    engine = PriorityEngine()

    # Case 1: Required skill with zero evidence (P0 Critical)
    score_p0, rank_p0, bd_p0 = engine.compute_priority(
        skill_name="Docker",
        importance=RequirementImportance.REQUIRED,
        evidence_status=EvidenceStatus.NOT_FOUND,
        evidence_strength=0.0
    )
    assert score_p0 >= 0.75
    assert rank_p0 == PriorityRank.P0_CRITICAL
    assert bd_p0.importance_weight == 1.0
    assert bd_p0.evidence_gap_weight == 1.0
    assert "Formula:" in bd_p0.formula_explanation

    # Case 2: Nice-to-have skill with partial evidence (P2 or P3)
    score_p2, rank_p2, bd_p2 = engine.compute_priority(
        skill_name="GraphQL",
        importance=RequirementImportance.NICE_TO_HAVE,
        evidence_status=EvidenceStatus.PARTIAL,
        evidence_strength=0.5
    )
    assert score_p2 < score_p0
    assert rank_p2 in [PriorityRank.P2_MEDIUM, PriorityRank.P3_LOW]
