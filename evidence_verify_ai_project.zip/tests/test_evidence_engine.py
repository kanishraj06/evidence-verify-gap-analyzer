import pytest
from backend.app.models.schemas import (
    ResumeStructured,
    PersonalInfo,
    ProjectItem,
    ExperienceItem,
    CertificationItem,
    EvidenceStatus
)
from backend.app.engines.evidence_engine import EvidenceVerificationEngine

def test_skills_section_never_treated_as_proof():
    """Ensure a skill only claimed in the skills section is classified as CLAIMED_UNVERIFIED."""
    engine = EvidenceVerificationEngine()
    resume = ResumeStructured(
        personal_info=PersonalInfo(name="Test Candidate"),
        skills_claimed=["Kubernetes", "Redis", "Python"],
        projects=[
            ProjectItem(
                name="Web API",
                description="Built REST API with Python and FastAPI",
                technologies=["Python", "FastAPI"],
                implementation_evidence="Implemented FastAPI backend with Python."
            )
        ]
    )

    ev_map = engine.verify_skills_evidence(resume, ["Kubernetes", "Redis", "Python"])

    # Python should be supported
    assert ev_map["Python"].status in [EvidenceStatus.SUPPORTED, EvidenceStatus.STRONGLY_SUPPORTED]
    assert len(ev_map["Python"].evidence_locations) > 0

    # Kubernetes and Redis were ONLY claimed, not in projects or experience
    assert ev_map["Kubernetes"].status == EvidenceStatus.CLAIMED_UNVERIFIED
    assert len(ev_map["Kubernetes"].evidence_locations) == 0
    assert "no supporting implementation evidence" in ev_map["Kubernetes"].summary_verdict.lower()

    assert ev_map["Redis"].status == EvidenceStatus.CLAIMED_UNVERIFIED

def test_not_found_status_and_wording():
    """Ensure unmentioned skills are classified as NOT FOUND with standard phrasing."""
    engine = EvidenceVerificationEngine()
    resume = ResumeStructured(
        personal_info=PersonalInfo(name="Test Candidate"),
        skills_claimed=["Python"],
        projects=[]
    )

    ev_map = engine.verify_skills_evidence(resume, ["GraphQL", "Rust"])

    assert ev_map["GraphQL"].status == EvidenceStatus.NOT_FOUND
    assert ev_map["GraphQL"].summary_verdict == "No supporting evidence was found in the submitted resume."
    assert "the candidate doesn't know" not in ev_map["GraphQL"].summary_verdict.lower()

def test_strongly_supported_production_evidence():
    """Ensure production experience with quantifiable scale receives STRONGLY_SUPPORTED status."""
    engine = EvidenceVerificationEngine()
    resume = ResumeStructured(
        personal_info=PersonalInfo(name="Senior Dev"),
        skills_claimed=["FastAPI", "PostgreSQL"],
        experience=[
            ExperienceItem(
                company="Tech Corp",
                role="Senior Engineer",
                description="Engineered high-scale FastAPI microservices handling 25,000 daily users in production.",
                technologies=["FastAPI", "PostgreSQL"],
                bullet_points=["Optimized PostgreSQL queries reducing latency by 40%."]
            )
        ],
        projects=[
            ProjectItem(
                name="SaaS Platform",
                description="Built multi-tenant FastAPI backend with PostgreSQL.",
                technologies=["FastAPI", "PostgreSQL"],
                implementation_evidence="Deployed containerized FastAPI application."
            )
        ]
    )

    ev_map = engine.verify_skills_evidence(resume, ["FastAPI", "PostgreSQL"])

    assert ev_map["FastAPI"].status == EvidenceStatus.STRONGLY_SUPPORTED
    assert ev_map["FastAPI"].strength_score >= 0.85
    assert len(ev_map["FastAPI"].evidence_locations) >= 2
