import pytest
from backend.app.ai.llm_adapter import LLMAdapter
from backend.app.engines.evidence_engine import EvidenceVerificationEngine
from backend.app.engines.requirement_matcher import RequirementMatcher
from backend.app.engines.gap_engine import GapEngine
from backend.app.engines.roadmap_engine import RoadmapEngine
from backend.app.models.schemas import EvidenceStatus
from backend.app.api.test_fixtures import (
    SAMPLE_RESUME_1_FULLSTACK,
    SAMPLE_RESUME_2_ML,
    SAMPLE_RESUME_3_DEVOPS_SCANNED,
    SAMPLE_JD_1_FULLSTACK,
    SAMPLE_JD_2_ML
)

def test_full_pipeline_alex_fullstack():
    llm = LLMAdapter()
    ev_engine = EvidenceVerificationEngine()
    matcher = RequirementMatcher()
    gap_engine = GapEngine()
    roadmap_engine = RoadmapEngine()

    # Parse Resume & JD
    resume = llm.extract_structured_resume(SAMPLE_RESUME_1_FULLSTACK)
    jd = llm.extract_structured_jd(SAMPLE_JD_1_FULLSTACK)

    assert resume.personal_info.name == "ALEX RIVERA"
    assert len(resume.projects) >= 2
    assert len(jd.required_skills) > 0

    # Verify Evidence
    target_skills = [s.skill_name for s in jd.required_skills + jd.preferred_skills + jd.nice_to_have_skills]
    ev_map = ev_engine.verify_skills_evidence(resume, target_skills)

    # FastAPI should be strongly supported / supported
    assert ev_map["FastAPI"].status in [EvidenceStatus.STRONGLY_SUPPORTED, EvidenceStatus.SUPPORTED]
    assert len(ev_map["FastAPI"].evidence_locations) > 0

    # Kubernetes was claimed in skills section, but not in projects or experience -> CLAIMED_UNVERIFIED
    assert ev_map["Kubernetes"].status == EvidenceStatus.CLAIMED_UNVERIFIED

    # Match requirements and generate gaps
    matched = matcher.match_requirements(jd, ev_map)
    gaps = gap_engine.analyze_gaps(matched, resume)
    assert len(gaps) > 0

    # Generate Roadmap
    roadmap = roadmap_engine.generate_roadmap(gaps, resume)
    assert len(roadmap) > 0
    assert "Phase 1:" in roadmap[0].phase_title

def test_full_pipeline_priya_ml():
    llm = LLMAdapter()
    ev_engine = EvidenceVerificationEngine()
    matcher = RequirementMatcher()
    gap_engine = GapEngine()
    roadmap_engine = RoadmapEngine()

    resume = llm.extract_structured_resume(SAMPLE_RESUME_2_ML)
    jd = llm.extract_structured_jd(SAMPLE_JD_2_ML)

    assert resume.personal_info.name == "PRIYA SHARMA"
    target_skills = [s.skill_name for s in jd.required_skills + jd.preferred_skills + jd.nice_to_have_skills]
    ev_map = ev_engine.verify_skills_evidence(resume, target_skills)

    # PyTorch has strong evidence
    assert ev_map["PyTorch"].status in [EvidenceStatus.STRONGLY_SUPPORTED, EvidenceStatus.SUPPORTED]

def test_full_pipeline_marcus_devops():
    llm = LLMAdapter()
    ev_engine = EvidenceVerificationEngine()
    matcher = RequirementMatcher()
    gap_engine = GapEngine()

    resume = llm.extract_structured_resume(SAMPLE_RESUME_3_DEVOPS_SCANNED)
    jd = llm.extract_structured_jd(SAMPLE_JD_1_FULLSTACK)

    target_skills = [s.skill_name for s in jd.required_skills + jd.preferred_skills + jd.nice_to_have_skills]
    ev_map = ev_engine.verify_skills_evidence(resume, target_skills)

    # Docker and AWS have strong evidence
    assert ev_map["Docker"].status in [EvidenceStatus.STRONGLY_SUPPORTED, EvidenceStatus.SUPPORTED]
    assert ev_map["AWS"].status in [EvidenceStatus.STRONGLY_SUPPORTED, EvidenceStatus.SUPPORTED]
