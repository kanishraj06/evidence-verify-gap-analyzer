import pytest
from backend.app.models.schemas import EvidenceRecord, EvidenceStatus, SkillRequirement, RequirementImportance
from backend.app.evidence_intelligence.feature_flag import is_evidence_engine_enabled
from backend.app.evidence_intelligence.synonym_mapper import TechSynonymMapper
from backend.app.evidence_intelligence.skill_graph import SkillDependencyGraph
from backend.app.evidence_intelligence.gap_classifier import GapClassifier, GapClassificationType
from backend.app.evidence_intelligence.maturity_engine import EvidenceMaturityEngine
from backend.app.evidence_intelligence.contradiction_engine import ContradictionDetectionEngine

def test_feature_flag_default_false(monkeypatch):
    monkeypatch.delenv("EVIDENCE_ENGINE_ENABLED", raising=False)
    assert is_evidence_engine_enabled() is False

def test_feature_flag_enabled(monkeypatch):
    monkeypatch.setenv("EVIDENCE_ENGINE_ENABLED", "true")
    assert is_evidence_engine_enabled() is True

def test_tech_synonyms():
    mapper = TechSynonymMapper()
    assert mapper.get_canonical_name("k8s") == "kubernetes"
    assert mapper.get_canonical_name("postgres") == "postgresql"
    assert mapper.get_canonical_name("sklearn") == "scikit-learn"

def test_skill_dependency_graph():
    graph = SkillDependencyGraph()
    prereqs = graph.get_prerequisites("kubernetes")
    assert "docker" in prereqs
    assert graph.get_ecosystem_cluster("fastapi") == "Backend Microservices"

def test_gap_classifier():
    classifier = GapClassifier()
    not_found_rec = EvidenceRecord(
        skill_name="Kubernetes",
        status=EvidenceStatus.NOT_FOUND,
        strength_score=0.0,
        is_claimed=False,
        summary_verdict="No supporting evidence was found in the submitted resume."
    )
    req = SkillRequirement(skill_name="Kubernetes", importance=RequirementImportance.REQUIRED)
    res = classifier.classify_gap("Kubernetes", not_found_rec, req)
    assert res["classification_type"] == GapClassificationType.FOUNDATIONAL_ABSENCE_GAP.value

def test_maturity_engine():
    engine = EvidenceMaturityEngine()
    rec = EvidenceRecord(
        skill_name="FastAPI",
        status=EvidenceStatus.STRONGLY_SUPPORTED,
        strength_score=0.9,
        is_claimed=True,
        summary_verdict="Strong evidence",
        implementation_depth="Production"
    )
    res = engine.assess_maturity(rec)
    assert "Level 3" in res["maturity_level"]
