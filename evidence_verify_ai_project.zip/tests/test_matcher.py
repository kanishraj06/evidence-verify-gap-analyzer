import pytest
from backend.app.models.schemas import (
    JobDescriptionStructured,
    SkillRequirement,
    RequirementImportance,
    EvidenceRecord,
    EvidenceStatus
)
from backend.app.engines.requirement_matcher import RequirementMatcher

def test_requirement_matcher():
    matcher = RequirementMatcher()
    jd = JobDescriptionStructured(
        title="Backend Developer",
        required_skills=[
            SkillRequirement(skill_name="FastAPI", importance=RequirementImportance.REQUIRED),
            SkillRequirement(skill_name="Docker", importance=RequirementImportance.REQUIRED)
        ],
        preferred_skills=[
            SkillRequirement(skill_name="Kubernetes", importance=RequirementImportance.PREFERRED)
        ]
    )

    evidence_map = {
        "FastAPI": EvidenceRecord(
            skill_name="FastAPI",
            status=EvidenceStatus.STRONGLY_SUPPORTED,
            strength_score=0.9,
            is_claimed=True,
            summary_verdict="Strong evidence",
            implementation_depth="Production"
        )
    }

    pairs = matcher.match_requirements(jd, evidence_map)
    assert len(pairs) == 3

    fastapi_pair = next(p for p in pairs if p[0].skill_name == "FastAPI")
    assert fastapi_pair[1].status == EvidenceStatus.STRONGLY_SUPPORTED

    docker_pair = next(p for p in pairs if p[0].skill_name == "Docker")
    assert docker_pair[1].status == EvidenceStatus.NOT_FOUND
