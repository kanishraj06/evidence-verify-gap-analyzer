# 🛡️ AI Placement Skill-Gap & Evidence Verification System

An end-to-end, deterministic **Evidence Verification & Decision-Support System** designed for career placement, skills verification, and transparent job-alignment preparation.

> **Central Verification Chain:** `CLAIM` ➔ `EVIDENCE` ➔ `REQUIREMENT` ➔ `GAP` ➔ `ACTION`  
> **Core Ethos:** *Never predicts hiring outcomes. Never certifies real-world ability. Grounded strictly in verifiable text provenance.*

---

## 🏆 Hackathon Judging Criteria Alignment

| Judging Dimension | Weight | How Our System Delivers |
| :--- | :---: | :--- |
| **Innovation** | 20 pts | Replaces keyword matchers and hallucinating LLM evaluators with a deterministic **Evidence Provenance & Verification Engine**. Never treats skills sections as proof. |
| **Technical Implementation** | 20 pts | Decoupled 5-layer architecture (Ingestion ➔ AI Semantic Layer ➔ Evidence Verification ➔ Deterministic Decision ➔ Presentation), Pydantic JSON-Schema validation, explainable mathematical priority formula, robust SQLite persistence, full test suite. |
| **Working Prototype** | 20 pts | Fully working end-to-end prototype: Upload PDF/Images/Text, inspect extracted entities, verify evidence with exact quotes, simulate portfolio impact with What-If Engine, and export phased roadmaps. |
| **Feasibility** | 10 pts | Built with standard, production-ready Python stack (FastAPI, Streamlit, PyMuPDF, Pydantic, Scikit-learn, SQLite). Runs offline with zero external dependencies, or with Gemini API. |
| **Impact** | 10 pts | Transforms career services and applicant preparation from guesswork/keyword-stuffing to actionable, evidence-building portfolio projects. |
| **Presentation & Q&A** | 10 pts | Clean Streamlit UI with interactive Evidence Explorer, inspectable formula breakdowns, and clear distinction between current vs simulated evidence. |

---

## 🎯 The Core Problem & State-of-the-Art Comparison

| Approach | Major Flaws & Limitations | How This System Solves It |
| :--- | :--- | :--- |
| **Traditional ATS / Regex Parsers** | Rewards keyword stuffing in skills lists; treats a raw word as proof of competence; zero depth verification. | **Rule 1:** Skills lists are never treated as proof. Mines only Projects, Experience, and Certifications for implementation evidence. |
| **LLM Black-Box Chatbots** | Produces arbitrary percentages ("87% match"); hallucinates evaluation criteria; unpredictable across runs. | **Deterministic Decision Layer:** Transparent mathematical priority formula where every weight is inspectable. |
| **Generic Course Recommenders** | Suggests generic 40-hour video courses with zero portfolio evidence creation. | **Evidence-Building Actions:** Recommends concrete portfolio implementations (e.g. *"Containerize your existing FastAPI project"*). |

---

## 🔬 Evidence Taxonomy (Strict 5 Statuses)

1. `STRONGLY SUPPORTED`: Direct, concrete implementation evidence with measurable scope, production deployment, or deep architecture (Strength: 0.85 - 1.0).
2. `SUPPORTED`: Direct implementation evidence in a project or work experience (Strength: 0.60 - 0.84).
3. `PARTIAL`: Mentioned in a secondary or assisting context, lacking deep hands-on proof (Strength: 0.30 - 0.59).
4. `CLAIMED / UNVERIFIED`: Listed in skills or summary, but zero supporting evidence in projects/experience.
5. `NOT FOUND`: Required by the target JD, with no supporting evidence in the submitted resume.

> **Standard Phrasing Rule:** When evidence is missing or absent:  
> `"No supporting evidence was found in the submitted resume."` *(NEVER "the candidate doesn't know X")*

---

## 📐 Transparent Priority Formula

Every gap priority is calculated deterministically with zero black-box scoring:

$$\text{Priority Score} = (\text{Importance} \times 0.35) + (\text{Evidence Deficit} \times 0.25) + (\text{Dependency} \times 0.15) + (\text{Relevance} \times 0.15) + (\text{Effort ROI} \times 0.10)$$

- **Tiers:**
  - $\ge 0.75 \implies \text{P0 - Critical Blocker}$
  - $\ge 0.58 \implies \text{P1 - High Priority}$
  - $\ge 0.40 \implies \text{P2 - Medium Priority}$
  - $< 0.40 \implies \text{P3 - Low Priority}$

---

## 🚀 Quick Start & How to Run

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure Environment (Optional for Gemini API)
Copy `.env.example` to `.env` and supply your Gemini API key:
```bash
GEMINI_API_KEY=your_key_here
```
*(Note: If no API key is provided, the system automatically uses its high-precision deterministic parser fallback with 100% feature parity!)*

### 3. Run the Test Suite
```bash
python -m pytest -v
```

### 4. Launch Backend & Frontend
**Run FastAPI Backend:**
```bash
uvicorn backend.app.main:app --host 127.0.0.1 --port 8000 --reload
```

**Run Streamlit Interactive Dashboard:**
```bash
streamlit run frontend/app.py
```
Open `http://localhost:8501` in your browser.

---

## 🧪 Included Demo Test Datasets

1. **Alex Rivera (Full-Stack Engineer)** vs **Senior Full-Stack Cloud Engineer JD**
   - *Demonstration:* Claims `Kubernetes` and `Redis` in skills section, but projects only prove `FastAPI`, `React`, `PostgreSQL`, and `Git`. Correctly flags `Kubernetes` as `CLAIMED / UNVERIFIED`.
2. **Priya Sharma (Machine Learning Engineer)** vs **ML Infrastructure Engineer JD**
   - *Demonstration:* Strong `PyTorch` and `FastAPI` evidence; gaps identified for production `Kubernetes` and `CI/CD`.
3. **Marcus Vance (DevOps & Cloud Engineer - Scanned PNG & Text)** vs **Senior Full-Stack Cloud Engineer JD**
   - *Demonstration:* High evidence in `Docker`, `AWS`, `Terraform`, `Linux`; identifies gaps in application-layer frameworks.
