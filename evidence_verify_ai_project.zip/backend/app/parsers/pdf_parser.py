import io
from typing import Dict, Any, List
import fitz # PyMuPDF

def extract_text_from_pdf_bytes(pdf_bytes: bytes) -> Dict[str, Any]:
    """
    Extracts text and page structure from PDF bytes using PyMuPDF.
    Detects if the PDF is text-based or scanned (image-only).
    """
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    pages_text: List[str] = []
    total_characters = 0
    
    for page_num in range(len(doc)):
        page = doc[page_num]
        text = page.get_text("text")
        pages_text.append(text)
        total_characters += len(text.strip())
        
    full_text = "\n\n".join(pages_text).strip()
    is_scanned = total_characters < 100 # If very few text characters, treat as scanned
    
    return {
        "full_text": full_text,
        "pages": pages_text,
        "page_count": len(doc),
        "is_scanned": is_scanned,
        "char_count": total_characters
    }
