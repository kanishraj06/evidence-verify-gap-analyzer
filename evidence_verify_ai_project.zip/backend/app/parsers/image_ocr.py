import io
from typing import Dict, Any
from PIL import Image

def extract_text_from_image_bytes(image_bytes: bytes) -> Dict[str, Any]:
    """
    Extracts text from image bytes using pytesseract OCR and PIL.
    Gracefully handles environment where tesseract binary might not be on system path.
    """
    image = Image.open(io.BytesIO(image_bytes))
    extracted_text = ""
    ocr_engine = "none"
    
    try:
        import pytesseract
        extracted_text = pytesseract.image_to_string(image)
        ocr_engine = "pytesseract"
    except Exception as e:
        ocr_engine = f"pytesseract_unavailable: {str(e)}"
        
    return {
        "full_text": extracted_text.strip(),
        "image_format": image.format,
        "image_size": image.size,
        "ocr_engine": ocr_engine
    }
