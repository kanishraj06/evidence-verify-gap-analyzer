import fitz
from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
from backend.app.api.test_fixtures import (
    SAMPLE_RESUME_1_FULLSTACK,
    SAMPLE_RESUME_2_ML,
    SAMPLE_RESUME_3_DEVOPS_SCANNED,
    SAMPLE_JD_1_FULLSTACK,
    SAMPLE_JD_2_ML
)

DATA_DIR = Path(__file__).resolve().parent.parent / "data" / "samples"
DATA_DIR.mkdir(parents=True, exist_ok=True)

# 1. Write text files
(DATA_DIR / "resume_1_fullstack.txt").write_text(SAMPLE_RESUME_1_FULLSTACK, encoding="utf-8")
(DATA_DIR / "resume_2_ml.txt").write_text(SAMPLE_RESUME_2_ML, encoding="utf-8")
(DATA_DIR / "resume_3_devops.txt").write_text(SAMPLE_RESUME_3_DEVOPS_SCANNED, encoding="utf-8")
(DATA_DIR / "jd_1_fullstack.txt").write_text(SAMPLE_JD_1_FULLSTACK, encoding="utf-8")
(DATA_DIR / "jd_2_ml.txt").write_text(SAMPLE_JD_2_ML, encoding="utf-8")

# 2. Generate PDF for Resume 1
doc = fitz.open()
page = doc.new_page(width=595, height=842) # A4
p = fitz.Point(40, 50)
page.insert_text(p, SAMPLE_RESUME_1_FULLSTACK, fontsize=9.5, fontname="helv", color=(0.1, 0.1, 0.1))
doc.save(str(DATA_DIR / "resume_1_fullstack.pdf"))
doc.close()

# 3. Generate PDF for JD 1
doc_jd = fitz.open()
page_jd = doc_jd.new_page(width=595, height=842)
page_jd.insert_text(fitz.Point(40, 50), SAMPLE_JD_1_FULLSTACK, fontsize=9.5, fontname="helv", color=(0.1, 0.1, 0.1))
doc_jd.save(str(DATA_DIR / "jd_1_fullstack.pdf"))
doc_jd.close()

# 4. Generate Scanned Image (PNG) for Resume 3
img = Image.new("RGB", (1000, 1400), color=(250, 250, 250))
draw = ImageDraw.Draw(img)
# Draw text lines on image
y_offset = 50
for line in SAMPLE_RESUME_3_DEVOPS_SCANNED.split("\n"):
    draw.text((50, y_offset), line, fill=(20, 20, 20))
    y_offset += 24
img.save(str(DATA_DIR / "resume_3_scanned_devops.png"))

print("Sample files generated successfully in:", DATA_DIR)
