from typing import Dict, Any
from .pdf_parser import extract_text_from_pdf_bytes
from .image_ocr import extract_text_from_image_bytes

def parse_document_file(filename: str, file_bytes: bytes) -> Dict[str, Any]:
    """
    Parses an uploaded resume or JD file based on extension (PDF, PNG, JPG, JPEG, TXT, MD).
    Returns structured parsed text with metadata.
    """
    fn_lower = filename.lower()
    
    if fn_lower.endswith(".pdf"):
        pdf_res = extract_text_from_pdf_bytes(file_bytes)
        return {
            "source_filename": filename,
            "file_type": "pdf",
            "full_text": pdf_res["full_text"],
            "page_count": pdf_res["page_count"],
            "is_scanned": pdf_res["is_scanned"],
            "raw_bytes": file_bytes
        }
    elif any(fn_lower.endswith(ext) for ext in [".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tiff"]):
        img_res = extract_text_from_image_bytes(file_bytes)
        return {
            "source_filename": filename,
            "file_type": "image",
            "full_text": img_res["full_text"],
            "page_count": 1,
            "is_scanned": True,
            "raw_bytes": file_bytes
        }
    else: # Plain text or markdown
        text = file_bytes.decode("utf-8", errors="ignore")
        return {
            "source_filename": filename,
            "file_type": "text",
            "full_text": text.strip(),
            "page_count": 1,
            "is_scanned": False,
            "raw_bytes": file_bytes
        }
