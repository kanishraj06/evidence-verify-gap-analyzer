from enum import Enum
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field

class EvidenceStatus(str, Enum):
    STRONGLY_SUPPORTED = "STRONGLY SUPPORTED"
    SUPPORTED = "SUPPORTED"
    PARTIAL = "PARTIAL"
    CLAIMED_UNVERIFIED = "CLAIMED / UNVERIFIED"
    NOT_FOUND = "NOT FOUND"

class RequirementImportance(str, Enum):
    REQUIRED = "REQUIRED"
    PREFERRED = "PREFERRED"
    NICE_TO_HAVE = "NICE TO HAVE"

class PriorityRank(str, Enum):
    P0_CRITICAL = "P0 - Critical"
    P1_HIGH = "P1 - High"
    P2_MEDIUM = "P2 - Medium"
    P3_LOW = "P3 - Low"

# ----------------- RESUME SCHEMAS -----------------

class PersonalInfo(BaseModel):
    name: str = "Candidate"
    email: Optional[str] = None
    phone: Optional[str] = None
    location: Optional[str] = None
    links: List[str] = Field(default_factory=list)

class EducationItem(BaseModel):
    degree: str
    institution: str
    year: Optional[str] = None
    field_of_study: Optional[str] = None
    grade_or_gpa: Optional[str] = None

class ExperienceItem(BaseModel):
    company: str
    role: str
    duration: Optional[str] = None
    description: str = ""
    technologies: List[str] = Field(default_factory=list)
    bullet_points: List[str] = Field(default_factory=list)

class ProjectItem(BaseModel):
    name: str
    description: str = ""
    technologies: List[str] = Field(default_factory=list)
    role: Optional[str] = None
    implementation_evidence: str = ""
    outcomes_or_metrics: Optional[str] = None

class CertificationItem(BaseModel):
    name: str
    issuer: Optional[str] = None
    year: Optional[str] = None
    credential_id: Optional[str] = None

class ResumeStructured(BaseModel):
    personal_info: PersonalInfo = Field(default_factory=PersonalInfo)
    education: List[EducationItem] = Field(default_factory=list)
    skills_claimed: List[str] = Field(default_factory=list)
    experience: List[ExperienceItem] = Field(default_factory=list)
    projects: List[ProjectItem] = Field(default_factory=list)
    certifications: List[CertificationItem] = Field(default_factory=list)
    raw_text: Optional[str] = None

# ----------------- JOB DESCRIPTION SCHEMAS -----------------

class SkillRequirement(BaseModel):
    skill_name: str
    category: str = "Core Engineering"
    importance: RequirementImportance = RequirementImportance.REQUIRED
    context: str = ""
    stated_depth: Optional[str] = None # e.g. "3+ years", "production experience"

class JobDescriptionStructured(BaseModel):
    title: str = "Target Role"
    company: Optional[str] = None
    domain: Optional[str] = None
    experience_level: Optional[str] = None
    required_skills: List[SkillRequirement] = Field(default_factory=list)
    preferred_skills: List[SkillRequirement] = Field(default_factory=list)
    nice_to_have_skills: List[SkillRequirement] = Field(default_factory=list)
    tools_and_frameworks: List[str] = Field(default_factory=list)
    responsibilities: List[str] = Field(default_factory=list)
    education_requirement: Optional[str] = None
    raw_text: Optional[str] = None

# ----------------- EVIDENCE & MATCHING SCHEMAS -----------------

class EvidenceProvenance(BaseModel):
    section: str # 'projects' | 'experience' | 'certifications' | 'skills_summary'
    item_title: str # Project name, Company name, etc.
    exact_quote: str
    direct_vs_indirect: str = "direct" # 'direct' | 'indirect'
    strength_contribution: float = 0.0

class EvidenceRecord(BaseModel):
    skill_name: str
    status: EvidenceStatus
    strength_score: float = Field(ge=0.0, le=1.0)
    is_claimed: bool = False
    evidence_locations: List[EvidenceProvenance] = Field(default_factory=list)
    summary_verdict: str
    implementation_depth: str = "None" # 'Production' | 'Project Built' | 'Configured' | 'Academic' | 'None'
    maturity_level: Optional[str] = None # Optional Intelligence extension

class PriorityBreakdown(BaseModel):
    importance_weight: float
    evidence_gap_weight: float
    dependency_weight: float
    relevance_weight: float
    learning_effort_norm: float
    final_score: float
    formula_explanation: str

class GapAnalysisItem(BaseModel):
    skill: str
    category: str
    requirement_importance: RequirementImportance
    current_status: EvidenceStatus
    evidence_found: str
    gap_reason: str
    priority_score: float
    priority_rank: PriorityRank
    priority_breakdown: PriorityBreakdown
    suggested_action: str
    gap_classification: Optional[str] = None # Optional Intelligence extension

# ----------------- WHAT-IF & ROADMAP SCHEMAS -----------------

class SimulatedProjectInput(BaseModel):
    project_name: str
    technologies_targeted: List[str]
    description: str
    implementation_depth: str = "Project Built"

class WhatIfSimulationResult(BaseModel):
    simulated_inputs: List[SimulatedProjectInput]
    skill_status_changes: Dict[str, Dict[str, Any]] # skill -> {before: status, after: status, change_explanation: str}
    gaps_resolved_count: int
    remaining_gaps_count: int
    updated_gap_list: List[GapAnalysisItem]
    simulated_readiness_lift: float # delta % readiness points

class RoadmapPhase(BaseModel):
    phase_number: int
    phase_title: str
    duration_weeks: str
    skills_addressed: List[str]
    learning_objective: str
    practical_project: str
    portfolio_evidence: str
    target_alignment_impact: str

class VerificationReport(BaseModel):
    candidate_name: str
    target_role: str
    timestamp: str
    evidence_summary_counts: Dict[str, int]
    skill_evidence_records: List[EvidenceRecord]
    gaps: List[GapAnalysisItem]
    roadmap: List[RoadmapPhase]
    metadata: Dict[str, Any] = Field(default_factory=dict)
