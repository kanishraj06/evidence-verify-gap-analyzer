import sqlite3
import json
from typing import Dict, Any, Optional, List
from pathlib import Path
from .config import DATABASE_URL

DB_PATH = Path(DATABASE_URL.replace("sqlite:///", ""))

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS analyses (
            id TEXT PRIMARY KEY,
            candidate_name TEXT,
            target_role TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            resume_json TEXT,
            jd_json TEXT,
            report_json TEXT
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS simulations (
            id TEXT PRIMARY KEY,
            analysis_id TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            simulation_input_json TEXT,
            simulation_result_json TEXT
        )
    """)
    conn.commit()
    conn.close()

def save_analysis(analysis_id: str, candidate_name: str, target_role: str, resume: dict, jd: dict, report: dict):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        INSERT OR REPLACE INTO analyses (id, candidate_name, target_role, resume_json, jd_json, report_json)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        analysis_id,
        candidate_name,
        target_role,
        json.dumps(resume),
        json.dumps(jd),
        json.dumps(report)
    ))
    conn.commit()
    conn.close()

def get_analysis(analysis_id: str) -> Optional[Dict[str, Any]]:
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT id, candidate_name, target_role, created_at, resume_json, jd_json, report_json FROM analyses WHERE id = ?", (analysis_id,))
    row = cursor.fetchone()
    conn.close()
    if not row:
        return None
    return {
        "id": row[0],
        "candidate_name": row[1],
        "target_role": row[2],
        "created_at": row[3],
        "resume": json.loads(row[4]),
        "jd": json.loads(row[5]),
        "report": json.loads(row[6])
    }

def list_analyses() -> List[Dict[str, Any]]:
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT id, candidate_name, target_role, created_at FROM analyses ORDER BY created_at DESC")
    rows = cursor.fetchall()
    conn.close()
    return [{"id": r[0], "candidate_name": r[1], "target_role": r[2], "created_at": r[3]} for r in rows]

# Initialize DB on module import
init_db()
