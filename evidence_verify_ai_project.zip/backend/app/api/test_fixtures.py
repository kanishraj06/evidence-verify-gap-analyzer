SAMPLE_RESUME_1_FULLSTACK = """ALEX RIVERA
Email: alex.rivera@example.com | Phone: +1-555-0199 | Location: Seattle, WA
GitHub: github.com/arivera-dev | LinkedIn: linkedin.com/in/alexrivera-dev

PROFESSIONAL SUMMARY
Full Stack Software Developer with 3+ years of experience building modern web applications and RESTful backend architectures using Python, FastAPI, React, and relational databases.

SKILLS
Programming: Python, JavaScript, TypeScript, SQL, Bash
Frameworks and Libraries: FastAPI, React, Flask, Node.js, Tailwind CSS
Databases and Caching: PostgreSQL, Redis, SQLite
DevOps and Cloud: Docker, Kubernetes, Git, GitHub Actions, AWS
Concepts: RESTful APIs, Microservices, Agile Development, Unit Testing

WORK EXPERIENCE
Software Engineer | Nexus Cloud Solutions (2022 - Present)
- Developed and maintained 12+ high-throughput REST APIs using FastAPI and PostgreSQL, serving over 25,000 active daily users with average response latency below 80ms.
- Built reusable React frontend components with TypeScript and Tailwind CSS, improving dashboard page load performance by 35%.
- Implemented automated database migration pipelines using Alembic and wrote comprehensive test suites with pytest achieving 88% code coverage.
- Configured Git version control branching strategies and reviewed pull requests across a cross-functional team of 6 engineers.

Junior Web Developer | InnovateTech Labs (2020 - 2022)
- Built internal administrative tools using Python, Flask, and SQLite for inventory reconciliation.
- Integrated third-party payment and messaging webhooks with asynchronous task queues.

PROJECTS
TaskFlow - Distributed Task Management System (FastAPI, React, PostgreSQL, Git)
- Architected and built an end-to-end task workflow engine using FastAPI backend and React frontend.
- Designed relational schemas in PostgreSQL with complex indexing to handle 500k+ task status transitions.
- Utilized Git for version control and automated linting checks.

SmartHealth Tracker (Python, Flask, SQLite)
- Engineered a health telemetry data visualization dashboard processing time-series vital records.
- Implemented authentication with JWT and secure cookie handling.

EDUCATION
B.S. in Computer Science | University of Washington (2016 - 2020)

CERTIFICATIONS
- AWS Certified Cloud Practitioner (2023)
"""

SAMPLE_RESUME_2_ML = """PRIYA SHARMA
Email: priya.sharma@example.com | Phone: +1-555-8821 | Location: San Francisco, CA
Portfolio: priyasharma-ml.dev | GitHub: github.com/psharma-ai

PROFESSIONAL SUMMARY
Machine Learning Engineer with strong foundational experience in deep learning, natural language processing, computer vision, and predictive modeling using PyTorch and Python.

TECHNICAL SKILLS
Languages: Python, SQL, R, C++
Machine Learning: PyTorch, TensorFlow, Scikit-learn, HuggingFace Transformers, Pandas, NumPy
Backend and Data: FastAPI, Flask, SQL, PostgreSQL, Spark
Cloud and DevOps: Docker, AWS, GCP, Kubernetes, MLflow, CI/CD
Methodologies: Model Evaluation, Fine-Tuning, Feature Engineering, Data Augmentation

PROFESSIONAL EXPERIENCE
Machine Learning Engineer | Apex AI Technologies (2023 - Present)
- Fine-tuned transformer models using PyTorch and HuggingFace for domain-specific medical document classification, achieving 94.2% F1-score across 50,000 clinical records.
- Engineered automated data preprocessing and feature extraction pipelines using Pandas and SQL, reducing ETL turnaround time by 45%.
- Built high-performance prediction inference endpoints using FastAPI, serving 1,200 requests per minute with P99 latency of 120ms.

Data Science Intern | DataSphere Analytics (2022 - 2023)
- Trained gradient boosted decision trees and regression models with Scikit-learn for customer churn prediction.
- Analyzed 10M+ transactional rows using complex SQL queries and generated executive KPI dashboards.

FEATURED PROJECTS
VisionInspect - Real-Time Defect Detection (PyTorch, OpenCV, FastAPI, Python)
- Implemented deep convolutional neural network for manufacturing defect detection using PyTorch, achieving 96% precision on test datasets.
- Packaged model inference pipeline into a lightweight FastAPI service with live webcam stream processing.

SemanticSearch Engine (PyTorch, HuggingFace, PostgreSQL)
- Developed a semantic embedding search vector pipeline indexing 100k scientific publications.
- Integrated PostgreSQL pgvector for approximate nearest neighbor similarity searches.

EDUCATION
M.S. in Artificial Intelligence | Stanford University (2021 - 2023)
B.Tech in Computer Engineering | IIT Bombay (2017 - 2021)

CERTIFICATIONS
- Deep Learning Specialization (Coursera / DeepLearning.AI, 2022)
"""

SAMPLE_RESUME_3_DEVOPS_SCANNED = """MARCUS VANCE
Email: marcus.vance@example.com | Phone: +1-555-4301 | Location: Austin, TX
GitHub: github.com/marcusv-ops

SUMMARY
DevOps and Cloud Infrastructure Engineer specializing in Linux systems, containerization, automated infrastructure deployment with Terraform, and cloud operations on AWS.

TECHNICAL SKILLS
Operating Systems and Tools: Linux, Ubuntu, Bash, Git, Ansible
Cloud Platforms: AWS (EC2, S3, RDS, VPC, IAM), GCP, Azure
Containerization and CI/CD: Docker, Docker Compose, Kubernetes, GitHub Actions, Jenkins
Infrastructure as Code: Terraform, CloudFormation
Databases and APIs: PostgreSQL, MySQL, Redis, GraphQL, REST APIs

EXPERIENCE
Cloud Operations Engineer | CloudScale Systems (2022 - Present)
- Provisioned and managed multi-AZ AWS cloud infrastructure using Terraform modules for 15+ production client environments.
- Built multi-stage Docker container build pipelines and configured automated GitHub Actions CI/CD workflows, cutting release deployment cycles from 4 hours to 12 minutes.
- Administered Linux production servers, hardening security groups, configuring SSH bastion hosts, and managing automated snapshot backups.
- Configured PostgreSQL database replication and automated failover policies on AWS RDS.

Infrastructure Support Specialist | DataCore Networks (2020 - 2022)
- Maintained Linux server clusters and diagnosed network connectivity, DNS, and SSL certificate issues.
- Wrote automated Bash shell scripts for log rotation, disk space alerting, and health monitoring.

PROJECTS
Automated Cloud IaC Blueprint (Terraform, AWS, Docker, Bash, Git)
- Developed modular Terraform templates for provisioning secure VPC architectures, subnets, EC2 auto-scaling groups, and Application Load Balancers on AWS.
- Containerized sample microservice workloads using Docker and orchestrated multi-container testing environments with Docker Compose.

Linux System Health Monitor (Bash, Linux, Git)
- Created a lightweight daemon in Bash monitoring CPU, memory, disk I/O, and sending webhook alerts to Slack.

EDUCATION
B.S. in Information Technology | University of Texas at Austin (2016 - 2020)

CERTIFICATIONS
- AWS Certified Solutions Architect - Associate (2023)
- HashiCorp Certified: Terraform Associate (2022)
"""

SAMPLE_JD_1_FULLSTACK = """Senior Full-Stack Cloud Engineer
Company: CloudPulse Systems
Domain: Enterprise SaaS and Cloud Platforms
Experience Level: Mid-to-Senior

JOB OVERVIEW
We are looking for a Senior Full-Stack Cloud Engineer to lead the development of our high-scale cloud management platform. You will design resilient backend microservices, build dynamic web interfaces, and deploy containerized workloads to cloud infrastructure.

REQUIRED SKILLS & QUALIFICATIONS (Must Have)
- 3+ years of hands-on experience building backend APIs and microservices using Python and FastAPI.
- Strong proficiency in modern frontend frameworks, specifically React with TypeScript.
- Deep expertise in relational database architecture and query optimization with PostgreSQL.
- Production experience containerizing applications with Docker and deploying to AWS.
- Strong proficiency with Git version control and collaborative code review workflows.

PREFERRED QUALIFICATIONS (Strong Plus)
- Experience orchestrating container workloads with Kubernetes in a production environment.
- In-depth knowledge of in-memory caching and message brokers using Redis.
- Hands-on experience creating automated CI/CD pipelines with GitHub Actions.

NICE TO HAVE (Bonus)
- Familiarity with GraphQL APIs and event-driven architecture with Kafka.
- Experience with infrastructure as code (Terraform).

RESPONSIBILITIES
- Architect scalable REST APIs and responsive React applications.
- Optimize database queries and ensure 99.9% uptime of core cloud services.
- Collaborate with product and design teams to deliver high-impact product features.
"""

SAMPLE_JD_2_ML = """Machine Learning Infrastructure Engineer
Company: DeepScale AI Labs
Domain: Generative AI and High-Throughput Inference
Experience Level: Mid-Level

JOB OVERVIEW
DeepScale AI is seeking a Machine Learning Infrastructure Engineer to bridge the gap between AI research models and high-throughput production inference systems.

REQUIRED SKILLS & QUALIFICATIONS (Must Have)
- Proven experience building, evaluating, and fine-tuning deep learning models using PyTorch.
- Hands-on experience developing low-latency model inference microservices with Python and FastAPI.
- Production containerization experience with Docker for GPU/CPU workloads.
- Proficiency in relational databases and data querying using SQL and PostgreSQL.
- Solid understanding of Git version control and software testing with pytest.

PREFERRED QUALIFICATIONS (Strong Plus)
- Production deployment and cluster management experience with Kubernetes.
- Experience building automated CI/CD pipelines for ML models (MLOps).
- Cloud experience on AWS (SageMaker, ECS, or EKS).

NICE TO HAVE (Bonus)
- Experience with distributed computing frameworks like Apache Spark or Ray.
- Familiarity with vector databases and embedding search (e.g. pgvector, Pinecone).

RESPONSIBILITIES
- Deploy and scale PyTorch deep learning models to low-latency production APIs.
- Build resilient data pipelines and optimize inference throughput.
"""
