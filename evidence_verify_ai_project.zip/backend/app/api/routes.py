import uuid
from datetime import datetime
from typing import Optional, List
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from pydantic import BaseModel

from ..models.schemas import (
    ResumeStructured,
    JobDescriptionStructured,
    VerificationReport,
    SimulatedProjectInput,
    WhatIfSimulationResult,
    EvidenceStatus
)
from ..parsers.document_loader import parse_document_file
from ..ai.llm_adapter import LLMAdapter
from ..engines.evidence_engine import EvidenceVerificationEngine
from ..engines.requirement_matcher import RequirementMatcher
from ..engines.gap_engine import GapEngine
from ..engines.roadmap_engine import RoadmapEngine
from ..engines.what_if_engine import WhatIfSimulatorEngine
from ..database import save_analysis, get_analysis, list_analyses
from .test_fixtures import (
    SAMPLE_RESUME_1_FULLSTACK,
    SAMPLE_RESUME_2_ML,
    SAMPLE_RESUME_3_DEVOPS_SCANNED,
    SAMPLE_JD_1_FULLSTACK,
    SAMPLE_JD_2_ML
)

router = APIRouter(prefix="/api")

llm_adapter = LLMAdapter()
evidence_engine = EvidenceVerificationEngine()
matcher = RequirementMatcher()
gap_engine = GapEngine()
roadmap_engine = RoadmapEngine()
what_if_engine = WhatIfSimulatorEngine()

# ----------------- HEALTH & SAMPLE FIXTURES -----------------

@router.get("/health")
def health_check():
    return {
        "status": "healthy",
        "service": "AI Placement Skill-Gap & Evidence Verification System",
        "version": "1.0.0"
    }

@router.get("/samples")
def get_sample_datasets():
    return {
        "resumes": [
            {
                "id": "resume_1",
                "label": "Alex Rivera (Full-Stack Dev)",
                "description": "Strong FastAPI & React evidence; claims Kubernetes & Redis without project backing.",
                "text": SAMPLE_RESUME_1_FULLSTACK
            },
            {
                "id": "resume_2",
                "label": "Priya Sharma (Machine Learning Engineer)",
                "description": "Strong PyTorch & NLP model training evidence; claims Docker & AWS, lacks production CI/CD.",
                "text": SAMPLE_RESUME_2_ML
            },
            {
                "id": "resume_3",
                "label": "Marcus Vance (DevOps & Cloud Engineer)",
                "description": "Strong Docker, Linux, Terraform, AWS evidence; claims Kubernetes & GraphQL without evidence.",
                "text": SAMPLE_RESUME_3_DEVOPS_SCANNED
            }
        ],
        "job_descriptions": [
            {
                "id": "jd_1",
                "label": "Senior Full-Stack Cloud Engineer (CloudPulse)",
                "description": "Requires FastAPI, React, PostgreSQL, Docker, AWS; Prefers Kubernetes & Redis.",
                "text": SAMPLE_JD_1_FULLSTACK
            },
            {
                "id": "jd_2",
                "label": "Machine Learning Infrastructure Engineer (DeepScale AI)",
                "description": "Requires PyTorch, FastAPI, Docker, SQL; Prefers Kubernetes, MLOps, AWS.",
                "text": SAMPLE_JD_2_ML
            }
        ]
    }

# ----------------- PARSING & EXTRACTION -----------------

@router.post("/extract/resume", response_model=ResumeStructured)
async def extract_resume(
    file: Optional[UploadFile] = File(None),
    raw_text: Optional[str] = Form(None)
):
    text_content = raw_text or ""
    image_bytes = None
    mime_type = "image/png"

    if file:
        file_bytes = await file.read()
        parsed = parse_document_file(file.filename, file_bytes)
        text_content = parsed["full_text"]
        if parsed["file_type"] == "image":
            image_bytes = file_bytes
            mime_type = f"image/{file.filename.split('.')[-1].lower()}"

    if not text_content and not image_bytes:
        raise HTTPException(status_code=400, detail="No resume document or text was provided.")

    structured_resume = llm_adapter.extract_structured_resume(
        raw_text=text_content,
        image_bytes=image_bytes,
        mime_type=mime_type
    )
    return structured_resume

@router.post("/extract/jd", response_model=JobDescriptionStructured)
async def extract_jd(
    file: Optional[UploadFile] = File(None),
    raw_text: Optional[str] = Form(None)
):
    text_content = raw_text or ""
    image_bytes = None
    mime_type = "image/png"

    if file:
        file_bytes = await file.read()
        parsed = parse_document_file(file.filename, file_bytes)
        text_content = parsed["full_text"]
        if parsed["file_type"] == "image":
            image_bytes = file_bytes
            mime_type = f"image/{file.filename.split('.')[-1].lower()}"

    if not text_content and not image_bytes:
        raise HTTPException(status_code=400, detail="No job description document or text was provided.")

    structured_jd = llm_adapter.extract_structured_jd(
        raw_text=text_content,
        image_bytes=image_bytes,
        mime_type=mime_type
    )
    return structured_jd

# ----------------- FULL VERIFICATION & MATCHING -----------------

class AnalyzeRequest(BaseModel):
    resume: ResumeStructured
    jd: JobDescriptionStructured

@router.post("/analyze", response_model=VerificationReport)
def run_full_analysis(payload: AnalyzeRequest):
    resume = payload.resume
    jd = payload.jd

    target_skills = [
        s.skill_name for s in jd.required_skills + jd.preferred_skills + jd.nice_to_have_skills
    ]

    # 1. Evidence Verification Layer
    evidence_map = evidence_engine.verify_skills_evidence(resume, target_skills)
    evidence_records_list = list(evidence_map.values())

    # Evidence summary counts
    summary_counts = {
        EvidenceStatus.STRONGLY_SUPPORTED.value: sum(1 for e in evidence_records_list if e.status == EvidenceStatus.STRONGLY_SUPPORTED),
        EvidenceStatus.SUPPORTED.value: sum(1 for e in evidence_records_list if e.status == EvidenceStatus.SUPPORTED),
        EvidenceStatus.PARTIAL.value: sum(1 for e in evidence_records_list if e.status == EvidenceStatus.PARTIAL),
        EvidenceStatus.CLAIMED_UNVERIFIED.value: sum(1 for e in evidence_records_list if e.status == EvidenceStatus.CLAIMED_UNVERIFIED),
        EvidenceStatus.NOT_FOUND.value: sum(1 for e in evidence_records_list if e.status == EvidenceStatus.NOT_FOUND),
    }

    # 2. Matcher Layer
    matched_pairs = matcher.match_requirements(jd, evidence_map)

    # 3. Gap Engine
    gaps = gap_engine.analyze_gaps(matched_pairs, resume)

    # 4. Roadmap Engine
    roadmap = roadmap_engine.generate_roadmap(gaps, resume)

    analysis_id = str(uuid.uuid4())
    timestamp = datetime.now().isoformat()

    report = VerificationReport(
        candidate_name=resume.personal_info.name or "Candidate",
        target_role=jd.title or "Target Role",
        timestamp=timestamp,
        evidence_summary_counts=summary_counts,
        skill_evidence_records=evidence_records_list,
        gaps=gaps,
        roadmap=roadmap,
        metadata={"analysis_id": analysis_id, "company": jd.company or "N/A"}
    )

    # Save to SQLite
    save_analysis(
        analysis_id=analysis_id,
        candidate_name=report.candidate_name,
        target_role=report.target_role,
        resume=resume.model_dump(),
        jd=jd.model_dump(),
        report=report.model_dump()
    )

    return report

# ----------------- WHAT-IF SIMULATION -----------------

class SimulateRequest(BaseModel):
    resume: ResumeStructured
    jd: JobDescriptionStructured
    simulated_projects: List[SimulatedProjectInput]

@router.post("/simulate", response_model=WhatIfSimulationResult)
def run_what_if_simulation(payload: SimulateRequest):
    result = what_if_engine.simulate(
        current_resume=payload.resume,
        jd=payload.jd,
        simulated_projects=payload.simulated_projects
    )
    return result

# ----------------- HISTORY -----------------

@router.get("/history")
def get_history():
    return list_analyses()

@router.get("/analysis/{analysis_id}")
def get_saved_analysis(analysis_id: str):
    data = get_analysis(analysis_id)
    if not data:
        raise HTTPException(status_code=404, detail="Analysis session not found.")
    return data
