from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .api.routes import router

app = FastAPI(
    title="AI Placement Skill-Gap & Evidence Verification System",
    description="Evidence Verification and Decision-Support Engine for Career Placement and Skills Alignment.",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router)

# Feature Flagged Intelligence Extension
from .evidence_intelligence.feature_flag import is_evidence_engine_enabled
if is_evidence_engine_enabled():
    from .evidence_intelligence.routes import intelligence_router
    app.include_router(intelligence_router)

@app.get("/")
def root():
    return {
        "message": "AI Placement Skill-Gap & Evidence Verification API is running.",
        "docs_url": "/docs",
        "health_url": "/api/health"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.app.main:app", host="127.0.0.1", port=8000, reload=True)
