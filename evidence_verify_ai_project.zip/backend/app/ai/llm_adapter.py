import json
import re
from typing import Optional, Dict, Any
from ..config import GEMINI_API_KEY, GEMINI_MODEL
from ..models.schemas import (
    ResumeStructured,
    JobDescriptionStructured,
    PersonalInfo,
    EducationItem,
    ExperienceItem,
    ProjectItem,
    CertificationItem,
    SkillRequirement,
    RequirementImportance
)
from .prompts import RESUME_EXTRACTION_SYSTEM_PROMPT, JD_EXTRACTION_SYSTEM_PROMPT

class LLMAdapter:
    def __init__(self, api_key: Optional[str] = None, model: Optional[str] = None):
        self.api_key = api_key or GEMINI_API_KEY
        self.model_name = model or GEMINI_MODEL
        self.client = None
        if self.api_key:
            try:
                from google import genai
                self.client = genai.Client(api_key=self.api_key)
            except Exception as e:
                print(f"[LLMAdapter] Warning: Could not initialize Gemini client: {e}")

    def extract_structured_resume(
        self, 
        raw_text: str, 
        image_bytes: Optional[bytes] = None, 
        mime_type: str = "image/png"
    ) -> ResumeStructured:
        """
        Extracts structured resume using Gemini with structured JSON output,
        falling back to deterministic heuristic parsing if LLM is unavailable.
        """
        if self.client and (raw_text or image_bytes):
            try:
                from google.genai import types
                
                contents = []
                if image_bytes:
                    contents.append(
                        types.Part.from_bytes(data=image_bytes, mime_type=mime_type)
                    )
                if raw_text:
                    contents.append(f"Resume Content:\n{raw_text}")
                
                response = self.client.models.generate_content(
                    model=self.model_name,
                    contents=contents,
                    config=types.GenerateContentConfig(
                        system_instruction=RESUME_EXTRACTION_SYSTEM_PROMPT,
                        response_mime_type="application/json",
                        response_schema=ResumeStructured,
                        temperature=0.1
                    )
                )
                if response.text:
                    parsed_json = json.loads(response.text)
                    resume_obj = ResumeStructured(**parsed_json)
                    resume_obj.raw_text = raw_text
                    return resume_obj
            except Exception as e:
                print(f"[LLMAdapter] Gemini extraction error (falling back to deterministic parser): {e}")

        # Fallback deterministic extraction
        return self._heuristic_resume_parser(raw_text)

    def extract_structured_jd(
        self, 
        raw_text: str,
        image_bytes: Optional[bytes] = None,
        mime_type: str = "image/png"
    ) -> JobDescriptionStructured:
        """
        Extracts structured JD using Gemini structured schema or deterministic parser fallback.
        """
        if self.client and (raw_text or image_bytes):
            try:
                from google.genai import types
                contents = []
                if image_bytes:
                    contents.append(types.Part.from_bytes(data=image_bytes, mime_type=mime_type))
                if raw_text:
                    contents.append(f"Job Description Content:\n{raw_text}")
                
                response = self.client.models.generate_content(
                    model=self.model_name,
                    contents=contents,
                    config=types.GenerateContentConfig(
                        system_instruction=JD_EXTRACTION_SYSTEM_PROMPT,
                        response_mime_type="application/json",
                        response_schema=JobDescriptionStructured,
                        temperature=0.1
                    )
                )
                if response.text:
                    parsed_json = json.loads(response.text)
                    jd_obj = JobDescriptionStructured(**parsed_json)
                    jd_obj.raw_text = raw_text
                    return jd_obj
            except Exception as e:
                print(f"[LLMAdapter] Gemini JD extraction error: {e}")

        # Fallback deterministic parser
        return self._heuristic_jd_parser(raw_text)

    def _heuristic_resume_parser(self, text: str) -> ResumeStructured:
        """High-precision heuristic parser for offline/test reliability."""
        text = text or ""
        lines = [line.strip() for line in text.split("\n") if line.strip()]
        
        # Name & Email extraction
        email_match = re.search(r'[\w\.-]+@[\w\.-]+\.\w+', text)
        email = email_match.group(0) if email_match else None
        phone_match = re.search(r'(\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}', text)
        phone = phone_match.group(0) if phone_match else None
        
        candidate_name = lines[0] if lines else "Candidate"
        if len(candidate_name) > 40 or "@" in candidate_name or "resume" in candidate_name.lower():
            candidate_name = "Candidate"

        # Sections detection
        sections = {"skills": [], "experience": [], "projects": [], "education": [], "certifications": []}
        current_section = "skills"
        
        section_headers = {
            "skill": "skills", "skills": "skills", "technical skills": "skills", "technologies": "skills", "programming": "skills",
            "experience": "experience", "work experience": "experience", "employment": "experience", "professional experience": "experience",
            "project": "projects", "projects": "projects", "academic projects": "projects", "key projects": "projects", "featured projects": "projects",
            "education": "education", "academic background": "education",
            "certification": "certifications", "certifications": "certifications", "certificates": "certifications", "licenses": "certifications"
        }
        
        for line in lines:
            lower_line = line.lower().strip(":#=- ")
            matched_sec = None
            for key, sec in section_headers.items():
                if lower_line == key or lower_line.startswith(key + " ") or lower_line.endswith(" " + key):
                    matched_sec = sec
                    break
            if matched_sec:
                current_section = matched_sec
            else:
                sections[current_section].append(line)

        # Skills claimed
        skills_claimed = []
        for sline in sections["skills"]:
            items = re.split(r'[,|•\-\/;]+', sline)
            for item in items:
                clean = item.strip()
                if clean and len(clean) < 35 and not any(k in clean.lower() for k in ["skill", "proficient", "familiar", "languages"]):
                    skills_claimed.append(clean)

        # Projects
        projects = []
        proj_lines = sections["projects"]
        current_proj_title = None
        current_proj_lines = []

        def flush_project(title, lines_list):
            if not title:
                return
            techs = []
            t_match = re.search(r'\((.*?)\)|\[(.*?)\]', title)
            clean_title = title
            if t_match:
                tech_str = t_match.group(1) or t_match.group(2)
                techs = [t.strip() for t in tech_str.split(",") if t.strip()]
                clean_title = re.sub(r'\(.*?\)|\[.*?\]', '', title).strip()
            desc = " ".join(lines_list) if lines_list else clean_title
            projects.append(ProjectItem(
                name=clean_title or "Project",
                description=desc,
                technologies=techs,
                implementation_evidence=desc
            ))

        for pline in proj_lines:
            pline_str = pline.strip()
            if not pline_str:
                continue
            if not pline_str.startswith(("-", "•", "*", "–")):
                # New project title detected
                if current_proj_title:
                    flush_project(current_proj_title, current_proj_lines)
                    current_proj_lines = []
                current_proj_title = pline_str
            else:
                current_proj_lines.append(pline_str.lstrip("-•*– "))

        if current_proj_title:
            flush_project(current_proj_title, current_proj_lines)

        # Experience
        experiences = []
        exp_blocks = "\n".join(sections["experience"]).split("\n\n")
        for blk in exp_blocks:
            blk_lines = [l.strip() for l in blk.split("\n") if l.strip()]
            if not blk_lines:
                continue
            role_line = blk_lines[0].lstrip("•-* ")
            desc = " ".join(blk_lines[1:]) if len(blk_lines) > 1 else role_line
            experiences.append(ExperienceItem(
                company="Organization",
                role=role_line,
                description=desc,
                bullet_points=blk_lines[1:] if len(blk_lines) > 1 else [role_line]
            ))

        # Certifications
        certifications = []
        for cline in sections["certifications"]:
            cline_clean = cline.lstrip("•-* ").strip()
            if cline_clean:
                certifications.append(CertificationItem(name=cline_clean))

        # Education
        education = []
        edu_text = " ".join(sections["education"])
        if edu_text:
            education.append(EducationItem(degree="Degree", institution=edu_text[:60]))

        return ResumeStructured(
            personal_info=PersonalInfo(name=candidate_name, email=email, phone=phone),
            education=education,
            skills_claimed=list(dict.fromkeys(skills_claimed)),
            experience=experiences,
            projects=projects,
            certifications=certifications,
            raw_text=text
        )

    def _heuristic_jd_parser(self, text: str) -> JobDescriptionStructured:
        """High-precision heuristic parser for offline/test JD parsing."""
        text = text or ""
        lines = [line.strip() for line in text.split("\n") if line.strip()]
        title = lines[0] if lines else "Software Engineer"
        
        # Extract common tech keywords
        common_tech_categories = {
            "Python": ("Backend & Data", RequirementImportance.REQUIRED),
            "FastAPI": ("Backend", RequirementImportance.REQUIRED),
            "Flask": ("Backend", RequirementImportance.PREFERRED),
            "Django": ("Backend", RequirementImportance.PREFERRED),
            "React": ("Frontend", RequirementImportance.REQUIRED),
            "TypeScript": ("Frontend & Languages", RequirementImportance.REQUIRED),
            "Docker": ("DevOps & Cloud", RequirementImportance.REQUIRED),
            "Kubernetes": ("DevOps & Cloud", RequirementImportance.PREFERRED),
            "PostgreSQL": ("Database", RequirementImportance.REQUIRED),
            "MongoDB": ("Database", RequirementImportance.PREFERRED),
            "Redis": ("Database & Caching", RequirementImportance.PREFERRED),
            "AWS": ("DevOps & Cloud", RequirementImportance.REQUIRED),
            "GCP": ("DevOps & Cloud", RequirementImportance.PREFERRED),
            "PyTorch": ("Machine Learning", RequirementImportance.REQUIRED),
            "TensorFlow": ("Machine Learning", RequirementImportance.PREFERRED),
            "SQL": ("Database", RequirementImportance.REQUIRED),
            "CI/CD": ("DevOps & Cloud", RequirementImportance.PREFERRED),
            "Git": ("Tools & Collaboration", RequirementImportance.REQUIRED),
            "REST API": ("Backend & Architecture", RequirementImportance.REQUIRED),
            "GraphQL": ("Backend & API", RequirementImportance.NICE_TO_HAVE),
            "Kafka": ("Distributed Systems", RequirementImportance.PREFERRED),
            "Microservices": ("System Architecture", RequirementImportance.REQUIRED),
        }

        required_skills = []
        preferred_skills = []
        nice_to_have = []
        tools = []
        
        lower_text = text.lower()
        for tech, (cat, default_imp) in common_tech_categories.items():
            pattern = r'\b' + re.escape(tech.lower()) + r'\b'
            if re.search(pattern, lower_text):
                tools.append(tech)
                # Determine requirement context
                context_match = re.search(r'([^.\n]*?' + re.escape(tech.lower()) + r'[^.\n]*)', lower_text)
                ctx = context_match.group(1).strip() if context_match else f"Experience with {tech}"
                
                imp = default_imp
                if any(w in ctx for w in ["nice to have", "bonus", "optional", "plus"]):
                    imp = RequirementImportance.NICE_TO_HAVE
                elif any(w in ctx for w in ["preferred", "advantage", "desired"]):
                    imp = RequirementImportance.PREFERRED
                elif any(w in ctx for w in ["must have", "required", "essential", "mandatory"]):
                    imp = RequirementImportance.REQUIRED

                req = SkillRequirement(
                    skill_name=tech,
                    category=cat,
                    importance=imp,
                    context=ctx
                )
                if imp == RequirementImportance.REQUIRED:
                    required_skills.append(req)
                elif imp == RequirementImportance.PREFERRED:
                    preferred_skills.append(req)
                else:
                    nice_to_have.append(req)

        return JobDescriptionStructured(
            title=title,
            required_skills=required_skills,
            preferred_skills=preferred_skills,
            nice_to_have_skills=nice_to_have,
            tools_and_frameworks=tools,
            responsibilities=["Build scalable services and deliver quality code."],
            raw_text=text
        )
