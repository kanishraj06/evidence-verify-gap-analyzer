import re
from typing import List, Dict, Any, Tuple
from ..models.schemas import (
    ResumeStructured,
    EvidenceRecord,
    EvidenceProvenance,
    EvidenceStatus
)

class EvidenceVerificationEngine:
    """
    Evidence Layer: Validates claimed and target skills against resume body (projects, experience, certifications).
    Strictly follows the principle: NEVER treat the Skills section as proof.
    """

    DEPTH_KEYWORDS = {
        "production": ["production", "deployed", "scaled", "kubernetes", "cloud", "aws", "gcp", "users", "traffic", "optimized", "ci/cd", "pipeline", "latency", "qps"],
        "project_built": ["implemented", "built", "architected", "developed", "engineered", "created", "designed", "integrated", "trained", "fine-tuned"],
        "configured": ["configured", "setup", "maintained", "utilized", "used", "assisted", "worked with"]
    }

    def verify_skills_evidence(
        self,
        resume: ResumeStructured,
        target_skills: List[str]
    ) -> Dict[str, EvidenceRecord]:
        """
        Verifies evidence for all candidate claimed skills + target JD skills.
        Returns a dictionary mapping skill_name to EvidenceRecord.
        """
        # Collect all unique skills to check (both claimed in resume and required by JD)
        all_skills_to_check = set()
        claimed_set = {s.strip().lower(): s.strip() for s in resume.skills_claimed if s.strip()}
        for s in resume.skills_claimed:
            if s.strip():
                all_skills_to_check.add(s.strip())
        for ts in target_skills:
            if ts.strip():
                all_skills_to_check.add(ts.strip())

        results: Dict[str, EvidenceRecord] = {}

        for skill in all_skills_to_check:
            record = self._analyze_single_skill_evidence(skill, resume, claimed_set)
            results[skill] = record

        return results

    def _analyze_single_skill_evidence(
        self,
        skill: str,
        resume: ResumeStructured,
        claimed_map: Dict[str, str]
    ) -> EvidenceRecord:
        skill_lower = skill.lower()
        is_claimed = skill_lower in claimed_map
        locations: List[EvidenceProvenance] = []

        # 1. Search in Projects (Primary Evidence Source)
        for proj in resume.projects:
            evidence_text = f"{proj.name}. {proj.description}. {proj.implementation_evidence}. {proj.outcomes_or_metrics or ''}"
            tech_list_lower = [t.lower() for t in proj.technologies]
            
            matched, is_direct, quote = self._find_evidence_in_text(skill_lower, evidence_text, tech_list_lower)
            if matched:
                score = self._compute_depth_score(quote, evidence_text)
                locations.append(EvidenceProvenance(
                    section="projects",
                    item_title=proj.name,
                    exact_quote=quote,
                    direct_vs_indirect="direct" if is_direct else "indirect",
                    strength_contribution=score
                ))

        # 2. Search in Work Experience (Primary Evidence Source)
        for exp in resume.experience:
            evidence_text = f"{exp.role} at {exp.company}. {exp.description}. {' '.join(exp.bullet_points)}"
            tech_list_lower = [t.lower() for t in exp.technologies]
            
            matched, is_direct, quote = self._find_evidence_in_text(skill_lower, evidence_text, tech_list_lower)
            if matched:
                score = self._compute_depth_score(quote, evidence_text) + 0.1 # Real work bonus
                score = min(score, 1.0)
                locations.append(EvidenceProvenance(
                    section="experience",
                    item_title=f"{exp.role} @ {exp.company}",
                    exact_quote=quote,
                    direct_vs_indirect="direct" if is_direct else "indirect",
                    strength_contribution=score
                ))

        # 3. Search in Certifications (Secondary Supporting Evidence)
        for cert in resume.certifications:
            if self._matches_token(skill_lower, cert.name.lower()):
                locations.append(EvidenceProvenance(
                    section="certifications",
                    item_title=cert.name,
                    exact_quote=f"Verified Certification: {cert.name} ({cert.issuer or 'Issuer Not Stated'})",
                    direct_vs_indirect="direct",
                    strength_contribution=0.55
                ))

        # 4. Status and Strength Computation
        if not locations:
            if is_claimed:
                # Skill was listed in Skills section, but zero evidence in projects/experience
                return EvidenceRecord(
                    skill_name=skill,
                    status=EvidenceStatus.CLAIMED_UNVERIFIED,
                    strength_score=0.15,
                    is_claimed=True,
                    evidence_locations=[],
                    summary_verdict="Claimed in skills section, but no supporting implementation evidence was found in projects or work experience.",
                    implementation_depth="None"
                )
            else:
                # Not listed, no evidence found anywhere
                return EvidenceRecord(
                    skill_name=skill,
                    status=EvidenceStatus.NOT_FOUND,
                    strength_score=0.0,
                    is_claimed=False,
                    evidence_locations=[],
                    summary_verdict="No supporting evidence was found in the submitted resume.",
                    implementation_depth="None"
                )

        # Aggregate evidence scores
        total_strength = sum(loc.strength_contribution for loc in locations)
        max_single_strength = max(loc.strength_contribution for loc in locations)
        # Combined score with diminishing returns
        aggregate_strength = min(1.0, max_single_strength + (0.15 * (len(locations) - 1)))

        has_production = any("production" in loc.exact_quote.lower() or loc.strength_contribution >= 0.85 for loc in locations)
        has_direct_project = any(loc.direct_vs_indirect == "direct" and loc.section in ["projects", "experience"] for loc in locations)

        if aggregate_strength >= 0.85 and (has_production or len(locations) >= 2):
            status = EvidenceStatus.STRONGLY_SUPPORTED
            depth = "Production / High-Scale"
            verdict = f"Strong evidence verified across {len(locations)} concrete project/work context(s) with implementation depth."
        elif aggregate_strength >= 0.55 and has_direct_project:
            status = EvidenceStatus.SUPPORTED
            depth = "Project Built"
            verdict = f"Direct implementation evidence verified in {len(locations)} project/experience context(s)."
        elif aggregate_strength >= 0.30:
            status = EvidenceStatus.PARTIAL
            depth = "Configured / Secondary"
            verdict = f"Partial supporting evidence identified, but lacks deep hands-on implementation details."
        else:
            if is_claimed:
                status = EvidenceStatus.CLAIMED_UNVERIFIED
                depth = "Claimed Only"
                verdict = "Skill claimed, but evidence is purely nominal or lacking practical context."
            else:
                status = EvidenceStatus.NOT_FOUND
                depth = "None"
                verdict = "No supporting evidence was found in the submitted resume."

        return EvidenceRecord(
            skill_name=skill,
            status=status,
            strength_score=round(aggregate_strength, 2),
            is_claimed=is_claimed,
            evidence_locations=locations,
            summary_verdict=verdict,
            implementation_depth=depth
        )

    def _find_evidence_in_text(
        self,
        skill_lower: str,
        text: str,
        tech_list_lower: List[str]
    ) -> Tuple[bool, bool, str]:
        """Finds if skill is in text or tech list, returning (matched, is_direct, quote)."""
        # Direct match in tech list
        if any(self._matches_token(skill_lower, t) for t in tech_list_lower):
            # Extract sentence from text
            sentences = re.split(r'[.\n]+', text)
            matching_sentences = [s.strip() for s in sentences if self._matches_token(skill_lower, s.lower())]
            quote = matching_sentences[0] if matching_sentences else f"Utilized {skill_lower.capitalize()} in implementation architecture."
            return True, True, quote

        # Match in full text
        sentences = re.split(r'[.\n]+', text)
        for s in sentences:
            s_clean = s.strip()
            if self._matches_token(skill_lower, s_clean.lower()):
                is_direct = any(verb in s_clean.lower() for verb in ["built", "developed", "trained", "deployed", "implemented", "wrote", "engineered", "designed"])
                return True, is_direct, s_clean

        return False, False, ""

    def _matches_token(self, skill: str, target_text: str) -> bool:
        """Robust token boundary matcher."""
        pattern = r'(?<![a-zA-Z0-9])' + re.escape(skill) + r'(?![a-zA-Z0-9])'
        return bool(re.search(pattern, target_text, re.IGNORECASE))

    def _compute_depth_score(self, quote: str, full_context: str) -> float:
        """Determines strength score based on concrete verbs, metrics, and complexity keywords."""
        q_lower = (quote + " " + full_context).lower()
        score = 0.50 # Base direct mention score

        # Check for production / scale keywords
        for kw in self.DEPTH_KEYWORDS["production"]:
            if kw in q_lower:
                score += 0.15
                break

        # Check for active implementation verbs
        for kw in self.DEPTH_KEYWORDS["project_built"]:
            if kw in q_lower:
                score += 0.15
                break

        # Check for quantitative metrics (e.g. "95% accuracy", "10k users", "40% latency reduction")
        if re.search(r'\d+%\s*|\d+k\s*|\d+x\s*|\b(ms|qps|users|queries)\b', q_lower):
            score += 0.15

        return min(0.95, score)
