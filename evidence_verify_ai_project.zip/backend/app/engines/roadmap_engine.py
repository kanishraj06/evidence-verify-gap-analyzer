from typing import List
from ..models.schemas import (
    GapAnalysisItem,
    RoadmapPhase,
    ResumeStructured,
    PriorityRank
)

class RoadmapEngine:
    """
    Roadmap Engine: Generates phased, evidence-building action plans.
    Focuses on building verifiable portfolio proof rather than abstract learning.
    Never recommends skills the candidate already has strong evidence for.
    """

    def generate_roadmap(
        self,
        gaps: List[GapAnalysisItem],
        resume: ResumeStructured
    ) -> List[RoadmapPhase]:
        if not gaps:
            return []

        # Filter out any non-gaps (only include items with actual deficits)
        active_gaps = [g for g in gaps if g.priority_score > 0.2]
        if not active_gaps:
            return []

        # Group gaps by priority tiers
        p0_gaps = [g for g in active_gaps if g.priority_rank == PriorityRank.P0_CRITICAL]
        p1_gaps = [g for g in active_gaps if g.priority_rank == PriorityRank.P1_HIGH]
        p2_gaps = [g for g in active_gaps if g.priority_rank in [PriorityRank.P2_MEDIUM, PriorityRank.P3_LOW]]

        phases: List[RoadmapPhase] = []
        phase_idx = 1

        existing_proj = resume.projects[0].name if resume.projects else "primary portfolio service"

        # Phase 1: Immediate Critical Gaps (P0)
        if p0_gaps:
            skills = [g.skill for g in p0_gaps]
            practical_actions = [g.suggested_action for g in p0_gaps]
            phases.append(RoadmapPhase(
                phase_number=phase_idx,
                phase_title="Phase 1: High-Priority Core Architecture & Blocker Resolution",
                duration_weeks="Weeks 1-2 (15-20 hrs)",
                skills_addressed=skills,
                learning_objective=f"Master practical core requirements ({', '.join(skills)}) directly demanded by target role.",
                practical_project=f"Build/Extend '{existing_proj}': {practical_actions[0]}",
                portfolio_evidence=f"Public GitHub repository containing tested source code, architecture diagram, and live container/API demonstration.",
                target_alignment_impact=f"Resolves {len(p0_gaps)} P0 Critical blocker(s), transforming unverified/missing skills into tangible evidence."
            ))
            phase_idx += 1

        # Phase 2: High-Impact Specialization (P1)
        if p1_gaps:
            skills = [g.skill for g in p1_gaps]
            practical_actions = [g.suggested_action for g in p1_gaps]
            phases.append(RoadmapPhase(
                phase_number=phase_idx,
                phase_title="Phase 2: Production Scaling, Tooling & Infrastructure",
                duration_weeks="Weeks 3-4 (15-20 hrs)",
                skills_addressed=skills,
                learning_objective=f"Implement production-grade standards for {', '.join(skills)}.",
                practical_project=f"Infrastructure & Pipeline Integration: {practical_actions[0]}",
                portfolio_evidence="End-to-end CI/CD workflow logs, automated test reports with >85% branch coverage, and benchmark latency charts in README.",
                target_alignment_impact=f"Elevates {len(p1_gaps)} P1 requirement(s) from Partial/Unverified to Supported status."
            ))
            phase_idx += 1

        # Phase 3: Ecosystem Polish & Preferred Bonus (P2/P3)
        if p2_gaps:
            skills = [g.skill for g in p2_gaps]
            phases.append(RoadmapPhase(
                phase_number=phase_idx,
                phase_title="Phase 3: Domain Polish & Nice-to-Have Ecosystem Extensions",
                duration_weeks="Weeks 5-6 (10-15 hrs)",
                skills_addressed=skills,
                learning_objective=f"Enrich technical versatility with preferred domain tools: {', '.join(skills)}.",
                practical_project=f"Deploy an interactive telemetry dashboard / supplementary module for '{existing_proj}' showcasing {', '.join(skills[:3])}.",
                portfolio_evidence="Live demo link hosted on cloud platform with comprehensive documentation and API endpoints.",
                target_alignment_impact=f"Differentiates candidate profile with {len(p2_gaps)} preferred bonus qualifications."
            ))

        return phases
