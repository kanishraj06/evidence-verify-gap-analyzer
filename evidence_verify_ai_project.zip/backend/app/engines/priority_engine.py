from typing import Dict
from ..models.schemas import (
    RequirementImportance,
    EvidenceStatus,
    PriorityBreakdown,
    PriorityRank
)

class PriorityEngine:
    """
    Priority Engine: Transparent, explainable mathematical formula scoring every gap.
    No arbitrary scores. Every component term is inspectable.
    """

    FOUNDATIONAL_DEPENDENCY_SKILLS = {
        "python": 0.95, "java": 0.90, "c++": 0.90, "javascript": 0.90, "typescript": 0.90,
        "sql": 0.90, "git": 0.85, "docker": 0.85, "rest api": 0.85, "fastapi": 0.80,
        "react": 0.80, "postgresql": 0.85, "linux": 0.80, "aws": 0.75, "kubernetes": 0.70
    }

    PRACTICAL_RELEVANCE_MAP = {
        "production": 0.95, "system design": 0.90, "ci/cd": 0.85, "docker": 0.90,
        "fastapi": 0.85, "sql": 0.90, "microservices": 0.85, "cloud": 0.80
    }

    # Normalized ROI/feasibility (1.0 = highly achievable evidence gain, 0.4 = long effort)
    LEARNING_EFFORT_MAP = {
        "docker": 0.85, "fastapi": 0.90, "git": 0.95, "sql": 0.85, "ci/cd": 0.80,
        "pytest": 0.90, "redis": 0.85, "mongodb": 0.85, "react": 0.70, "kubernetes": 0.50,
        "machine learning": 0.55, "distributed systems": 0.45
    }

    def compute_priority(
        self,
        skill_name: str,
        importance: RequirementImportance,
        evidence_status: EvidenceStatus,
        evidence_strength: float
    ) -> tuple[float, PriorityRank, PriorityBreakdown]:
        skill_key = skill_name.strip().lower()

        # 1. Importance weight (35%)
        if importance == RequirementImportance.REQUIRED:
            imp_weight = 1.0
        elif importance == RequirementImportance.PREFERRED:
            imp_weight = 0.65
        else:
            imp_weight = 0.35

        # 2. Evidence deficit (25%)
        evidence_gap_weight = max(0.0, 1.0 - evidence_strength)

        # 3. Dependency weight (15%)
        dependency_weight = self.FOUNDATIONAL_DEPENDENCY_SKILLS.get(skill_key, 0.60)

        # 4. Practical relevance (15%)
        relevance_weight = self.PRACTICAL_RELEVANCE_MAP.get(skill_key, 0.65)

        # 5. Learning effort ROI (10%)
        effort_norm = self.LEARNING_EFFORT_MAP.get(skill_key, 0.70)

        # Formula calculation
        final_score = (
            (imp_weight * 0.35) +
            (evidence_gap_weight * 0.25) +
            (dependency_weight * 0.15) +
            (relevance_weight * 0.15) +
            (effort_norm * 0.10)
        )
        final_score = round(min(1.0, max(0.0, final_score)), 3)

        # Priority Rank
        if final_score >= 0.75:
            rank = PriorityRank.P0_CRITICAL
        elif final_score >= 0.58:
            rank = PriorityRank.P1_HIGH
        elif final_score >= 0.40:
            rank = PriorityRank.P2_MEDIUM
        else:
            rank = PriorityRank.P3_LOW

        explanation = (
            f"Formula: (Importance {imp_weight} * 0.35) + (Evidence Deficit {evidence_gap_weight:.2f} * 0.25) + "
            f"(Dependency {dependency_weight} * 0.15) + (Relevance {relevance_weight} * 0.15) + "
            f"(Effort ROI {effort_norm} * 0.10) = {final_score:.3f}"
        )

        breakdown = PriorityBreakdown(
            importance_weight=imp_weight,
            evidence_gap_weight=round(evidence_gap_weight, 2),
            dependency_weight=dependency_weight,
            relevance_weight=relevance_weight,
            learning_effort_norm=effort_norm,
            final_score=final_score,
            formula_explanation=explanation
        )

        return final_score, rank, breakdown

# Type alias helper
TuplePriority = tuple[float, PriorityRank, PriorityBreakdown]
