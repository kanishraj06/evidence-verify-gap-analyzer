from typing import List, Dict, Any
from copy import deepcopy
from ..models.schemas import (
    ResumeStructured,
    JobDescriptionStructured,
    ProjectItem,
    SimulatedProjectInput,
    WhatIfSimulationResult,
    EvidenceStatus
)
from .evidence_engine import EvidenceVerificationEngine
from .requirement_matcher import RequirementMatcher
from .gap_engine import GapEngine

class WhatIfSimulatorEngine:
    """
    What-If Simulator Engine:
    Allows candidates to model the impact of building a practical project or acquiring a certification.
    CRITICAL RULE: Keeps 'Current Evidence' visibly separate from 'Simulated Future Evidence'.
    Never presents simulated skills as acquired real-world ability.
    """

    def __init__(self):
        self.evidence_engine = EvidenceVerificationEngine()
        self.matcher = RequirementMatcher()
        self.gap_engine = GapEngine()

    def simulate(
        self,
        current_resume: ResumeStructured,
        jd: JobDescriptionStructured,
        simulated_projects: List[SimulatedProjectInput]
    ) -> WhatIfSimulationResult:
        # 1. Base run on current resume
        target_skills = [s.skill_name for s in jd.required_skills + jd.preferred_skills + jd.nice_to_have_skills]
        base_ev_map = self.evidence_engine.verify_skills_evidence(current_resume, target_skills)
        base_matched = self.matcher.match_requirements(jd, base_ev_map)
        base_gaps = self.gap_engine.analyze_gaps(base_matched, current_resume)

        # 2. Construct simulated resume (deepcopy + add simulated projects)
        sim_resume = deepcopy(current_resume)
        for sp in simulated_projects:
            sim_resume.projects.append(ProjectItem(
                name=f"[SIMULATED] {sp.project_name}",
                description=f"(Simulated Project Proposal): {sp.description}",
                technologies=sp.technologies_targeted,
                implementation_evidence=f"Simulated evidence: Implementation of {', '.join(sp.technologies_targeted)} with {sp.implementation_depth} depth.",
                role="Lead Developer (Simulated Proposal)"
            ))
            # Also add to claimed skills in simulation
            for t in sp.technologies_targeted:
                if t not in sim_resume.skills_claimed:
                    sim_resume.skills_claimed.append(t)

        # 3. Run analysis on simulated resume
        sim_ev_map = self.evidence_engine.verify_skills_evidence(sim_resume, target_skills)
        sim_matched = self.matcher.match_requirements(jd, sim_ev_map)
        sim_gaps = self.gap_engine.analyze_gaps(sim_matched, sim_resume)

        # 4. Compute status changes
        status_changes: Dict[str, Dict[str, Any]] = {}
        for skill in target_skills:
            before_ev = base_ev_map.get(skill)
            after_ev = sim_ev_map.get(skill)
            before_status = before_ev.status if before_ev else EvidenceStatus.NOT_FOUND
            after_status = after_ev.status if after_ev else EvidenceStatus.NOT_FOUND

            if before_status != after_status:
                status_changes[skill] = {
                    "skill": skill,
                    "before_status": before_status.value,
                    "after_status": after_status.value,
                    "before_strength": before_ev.strength_score if before_ev else 0.0,
                    "after_strength": after_ev.strength_score if after_ev else 0.0,
                    "change_explanation": f"Elevated from '{before_status.value}' to simulated '{after_status.value}' via portfolio project."
                }

        # 5. Compute gap resolution stats
        base_gap_names = {g.skill for g in base_gaps}
        sim_gap_names = {g.skill for g in sim_gaps}
        resolved_count = len(base_gap_names - sim_gap_names)

        # Calculate alignment lift
        base_support_count = sum(1 for ev in base_ev_map.values() if ev.status in [EvidenceStatus.STRONGLY_SUPPORTED, EvidenceStatus.SUPPORTED])
        sim_support_count = sum(1 for ev in sim_ev_map.values() if ev.status in [EvidenceStatus.STRONGLY_SUPPORTED, EvidenceStatus.SUPPORTED])
        total_reqs = max(1, len(target_skills))
        base_pct = (base_support_count / total_reqs) * 100
        sim_pct = (sim_support_count / total_reqs) * 100
        lift = round(sim_pct - base_pct, 1)

        return WhatIfSimulationResult(
            simulated_inputs=simulated_projects,
            skill_status_changes=status_changes,
            gaps_resolved_count=resolved_count,
            remaining_gaps_count=len(sim_gaps),
            updated_gap_list=sim_gaps,
            simulated_readiness_lift=lift
        )
