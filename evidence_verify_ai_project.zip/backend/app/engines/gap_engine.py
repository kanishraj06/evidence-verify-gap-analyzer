from typing import List, Tuple, Dict
from ..models.schemas import (
    SkillRequirement,
    EvidenceRecord,
    EvidenceStatus,
    GapAnalysisItem,
    ResumeStructured
)
from .priority_engine import PriorityEngine

class GapEngine:
    """
    Gap Engine: Identifies gaps between target requirements and candidate evidence.
    Generates actionable evidence-building tasks and transparent priority rankings.
    """

    def __init__(self):
        self.priority_engine = PriorityEngine()

    def analyze_gaps(
        self,
        matched_pairs: List[Tuple[SkillRequirement, EvidenceRecord]],
        resume: ResumeStructured
    ) -> List[GapAnalysisItem]:
        gaps: List[GapAnalysisItem] = []

        for req, ev in matched_pairs:
            # Check if this requirement is satisfied with sufficient evidence
            if ev.status in [EvidenceStatus.STRONGLY_SUPPORTED, EvidenceStatus.SUPPORTED]:
                # Requirement is satisfied by verifiable evidence
                continue

            # Formulate gap reason strictly following wording rules
            if ev.status == EvidenceStatus.NOT_FOUND:
                gap_reason = "No supporting evidence was found in the submitted resume for this target job requirement."
                evidence_found_text = "No evidence found"
            elif ev.status == EvidenceStatus.CLAIMED_UNVERIFIED:
                gap_reason = "Skill is listed in candidate summary/skills section, but zero implementation evidence was found in projects or work experience."
                evidence_found_text = "Claimed in skills list only (no project/work backing)"
            elif ev.status == EvidenceStatus.PARTIAL:
                gap_reason = f"Candidate has partial/secondary mention ({ev.evidence_locations[0].item_title if ev.evidence_locations else 'general context'}), but lacks deep implementation proof or production metrics."
                evidence_found_text = f"Partial mention in {ev.evidence_locations[0].item_title if ev.evidence_locations else 'resume'}"
            elif ev.status == EvidenceStatus.SUPPORTED:
                # If it's a critical REQUIRED skill and only basic supported, flag as minor enhancement gap
                gap_reason = "Basic project evidence exists, but lacks production scale, CI/CD integration, or quantifiable performance metrics required for senior depth."
                evidence_found_text = f"Basic evidence in {len(ev.evidence_locations)} context(s)"
            else:
                gap_reason = "No supporting evidence was found in the submitted resume."
                evidence_found_text = "None"

            # Compute priority score
            score, rank, breakdown = self.priority_engine.compute_priority(
                skill_name=req.skill_name,
                importance=req.importance,
                evidence_status=ev.status,
                evidence_strength=ev.strength_score
            )

            # Generate contextual suggested action
            suggested_action = self._generate_suggested_action(req.skill_name, req.category, resume, ev)

            gaps.append(GapAnalysisItem(
                skill=req.skill_name,
                category=req.category,
                requirement_importance=req.importance,
                current_status=ev.status,
                evidence_found=evidence_found_text,
                gap_reason=gap_reason,
                priority_score=score,
                priority_rank=rank,
                priority_breakdown=breakdown,
                suggested_action=suggested_action
            ))

        # Sort gaps by priority score descending
        gaps.sort(key=lambda g: g.priority_score, reverse=True)
        return gaps

    def _generate_suggested_action(
        self,
        skill: str,
        category: str,
        resume: ResumeStructured,
        ev: EvidenceRecord
    ) -> str:
        """
        Generates concrete, portfolio-evidence oriented actions (e.g. "Containerize your FastAPI project").
        """
        skill_l = skill.lower()
        existing_projects = [p.name for p in resume.projects]
        primary_proj = existing_projects[0] if existing_projects else "your primary web application"

        if "docker" in skill_l:
            return f"Containerize '{primary_proj}' with a multi-stage Dockerfile and docker-compose orchestration, adding verifiable GitHub commit/deployment links."
        elif "kubernetes" in skill_l:
            return f"Create Helm charts and Kubernetes manifests for '{primary_proj}' with horizontal pod autoscaling (HPA) and deploy to a managed cluster."
        elif "fastapi" in skill_l or "backend" in category.lower():
            return f"Build and document an asynchronous REST API service with OpenAPI/Swagger specs, Pydantic validation, and unit tests using pytest."
        elif "react" in skill_l or "frontend" in category.lower():
            return f"Develop a responsive single-page web UI connected to your backend API, featuring state management and interactive visualizations."
        elif "sql" in skill_l or "postgresql" in skill_l or "database" in category.lower():
            return f"Implement relational schema design with indexing, migrations (Alembic/Flyway), and query optimization benchmarks for '{primary_proj}'."
        elif "aws" in skill_l or "gcp" in skill_l or "cloud" in category.lower():
            return f"Deploy '{primary_proj}' using automated Terraform / CloudFormation infrastructure with CI/CD pipeline on GitHub Actions."
        elif "pytorch" in skill_l or "machine learning" in category.lower():
            return f"Train and evaluate a PyTorch model with structured metrics logging, and serve it via an inference endpoint with FastAPI and Docker."
        elif "ci/cd" in skill_l:
            return f"Set up GitHub Actions CI/CD workflows running automated linting, pytest suites, and container build checks on every pull request."
        else:
            return f"Build a focused proof-of-concept module integrating {skill} into '{primary_proj}', documenting design rationale and benchmarking in the project README."
