from typing import List, Dict, Tuple
from ..models.schemas import (
    JobDescriptionStructured,
    SkillRequirement,
    EvidenceRecord,
    EvidenceStatus,
    RequirementImportance
)

class RequirementMatcher:
    """
    Requirement Matcher: Maps structured Job Description requirements against verified resume evidence.
    Deterministic, explainable, with zero hallucination.
    """

    def match_requirements(
        self,
        jd: JobDescriptionStructured,
        evidence_map: Dict[str, EvidenceRecord]
    ) -> List[Tuple[SkillRequirement, EvidenceRecord]]:
        """
        Pairs every JD requirement (Required, Preferred, Nice-to-have) with its verified EvidenceRecord.
        """
        all_reqs: List[SkillRequirement] = []
        all_reqs.extend(jd.required_skills)
        all_reqs.extend(jd.preferred_skills)
        all_reqs.extend(jd.nice_to_have_skills)

        # Remove duplicate requirements by skill_name
        seen_skills = set()
        unique_reqs = []
        for r in all_reqs:
            s_name = r.skill_name.strip()
            if s_name.lower() not in seen_skills:
                seen_skills.add(s_name.lower())
                unique_reqs.append(r)

        matched_pairs: List[Tuple[SkillRequirement, EvidenceRecord]] = []

        for req in unique_reqs:
            # Look up in evidence_map
            rec = None
            for ev_name, ev_rec in evidence_map.items():
                if ev_name.lower() == req.skill_name.lower():
                    rec = ev_rec
                    break
            
            if not rec:
                # Default to NOT FOUND
                rec = EvidenceRecord(
                    skill_name=req.skill_name,
                    status=EvidenceStatus.NOT_FOUND,
                    strength_score=0.0,
                    is_claimed=False,
                    evidence_locations=[],
                    summary_verdict="No supporting evidence was found in the submitted resume.",
                    implementation_depth="None"
                )
            
            matched_pairs.append((req, rec))

        return matched_pairs
