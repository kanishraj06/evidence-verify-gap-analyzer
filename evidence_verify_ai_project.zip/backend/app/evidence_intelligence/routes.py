from fastapi import APIRouter
from typing import List, Dict, Any
from pydantic import BaseModel

from ..models.schemas import ResumeStructured, JobDescriptionStructured
from ..engines.evidence_engine import EvidenceVerificationEngine
from ..engines.requirement_matcher import RequirementMatcher
from .gap_classifier import GapClassifier
from .maturity_engine import EvidenceMaturityEngine
from .contradiction_engine import ContradictionDetectionEngine
from .skill_graph import SkillDependencyGraph

intelligence_router = APIRouter(prefix="/api/intelligence", tags=["Evidence Intelligence"])

ev_engine = EvidenceVerificationEngine()
matcher = RequirementMatcher()
gap_classifier = GapClassifier()
maturity_engine = EvidenceMaturityEngine()
contradiction_engine = ContradictionDetectionEngine()
skill_graph = SkillDependencyGraph()

class IntelligenceAuditRequest(BaseModel):
    resume: ResumeStructured
    jd: JobDescriptionStructured

@intelligence_router.post("/audit")
def run_intelligence_audit(payload: IntelligenceAuditRequest) -> Dict[str, Any]:
    target_skills = [s.skill_name for s in payload.jd.required_skills + payload.jd.preferred_skills + payload.jd.nice_to_have_skills]
    ev_map = ev_engine.verify_skills_evidence(payload.resume, target_skills)
    matched_pairs = matcher.match_requirements(payload.jd, ev_map)

    # 1. Maturity analysis
    maturity_results = [maturity_engine.assess_maturity(rec) for rec in ev_map.values()]

    # 2. Gap classification
    gap_classifications = [
        gap_classifier.classify_gap(req.skill_name, rec, req)
        for req, rec in matched_pairs
        if rec.status.value not in ["STRONGLY SUPPORTED", "SUPPORTED"]
    ]

    # 3. Contradictions
    contradictions = contradiction_engine.audit_resume_contradictions(payload.resume, ev_map)

    return {
        "status": "success",
        "maturity_assessments": maturity_results,
        "gap_classifications": gap_classifications,
        "contradictions": contradictions
    }
