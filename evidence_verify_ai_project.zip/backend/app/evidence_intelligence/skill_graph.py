from typing import Dict, List, Set, Optional

SKILL_DEPENDENCY_EDGES: Dict[str, List[str]] = {
    "kubernetes": ["docker", "linux", "cloud"],
    "docker": ["linux"],
    "fastapi": ["python", "rest api"],
    "react": ["javascript", "typescript"],
    "typescript": ["javascript"],
    "pytorch": ["python", "machine learning"],
    "tensorflow": ["python", "machine learning"],
    "ci/cd": ["git", "docker"],
    "terraform": ["cloud", "aws", "gcp"],
    "helm": ["kubernetes", "docker"]
}

SKILL_CLUSTERS: Dict[str, List[str]] = {
    "Backend Microservices": ["python", "fastapi", "rest api", "postgresql", "redis", "docker"],
    "Cloud & Infrastructure": ["aws", "gcp", "docker", "kubernetes", "terraform", "ci/cd", "linux"],
    "Machine Learning & AI": ["python", "pytorch", "tensorflow", "scikit-learn", "sql", "fastapi"],
    "Modern Frontend": ["javascript", "typescript", "react", "rest api"]
}

class SkillDependencyGraph:
    """Directed acyclic relationship and prerequisite intelligence graph for technical skills."""

    def get_prerequisites(self, skill: str) -> List[str]:
        return SKILL_DEPENDENCY_EDGES.get(skill.strip().lower(), [])

    def get_ecosystem_cluster(self, skill: str) -> Optional[str]:
        s_lower = skill.strip().lower()
        for cluster_name, skills in SKILL_CLUSTERS.items():
            if s_lower in skills:
                return cluster_name
        return None

    def find_missing_prerequisites(self, skill: str, verified_skills: Set[str]) -> List[str]:
        prereqs = self.get_prerequisites(skill)
        verified_lower = {s.lower() for s in verified_skills}
        return [p for p in prereqs if p not in verified_lower]
