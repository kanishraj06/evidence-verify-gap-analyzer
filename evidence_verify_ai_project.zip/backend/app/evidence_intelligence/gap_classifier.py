from enum import Enum
from typing import Dict, Any, List
from ..models.schemas import EvidenceStatus, EvidenceRecord, SkillRequirement

class GapClassificationType(str, Enum):
    PRODUCTION_SCALE_GAP = "Production & Scale Gap"
    ARCHITECTURAL_GAP = "Architectural & Integration Gap"
    TOOLING_INFRASTRUCTURE_GAP = "Tooling & Infrastructure Gap"
    SYNTAX_FRAMEWORK_GAP = "Syntax & Framework Gap"
    FOUNDATIONAL_ABSENCE_GAP = "Foundational Absence Gap"

class GapClassifier:
    """Classifies gaps into granular engineering taxonomies to guide targeted portfolio remediation."""

    def classify_gap(
        self,
        skill_name: str,
        evidence_rec: EvidenceRecord,
        req: SkillRequirement
    ) -> Dict[str, Any]:
        s_lower = skill_name.lower()
        status = evidence_rec.status
        depth = evidence_rec.implementation_depth.lower()

        if status == EvidenceStatus.NOT_FOUND:
            g_type = GapClassificationType.FOUNDATIONAL_ABSENCE_GAP
            remediation_strategy = f"Build an initial working proof-of-concept project integrating {skill_name} from scratch."
        elif status == EvidenceStatus.CLAIMED_UNVERIFIED:
            g_type = GapClassificationType.ARCHITECTURAL_GAP
            remediation_strategy = f"Move {skill_name} from a passive keyword claim into an active implementation inside a featured project."
        elif "project built" in depth:
            g_type = GapClassificationType.PRODUCTION_SCALE_GAP
            remediation_strategy = f"Elevate existing {skill_name} project with production telemetry, load testing benchmarks, and container deployment."
        elif any(tool_kw in s_lower for tool_kw in ["docker", "ci/cd", "git", "kubernetes", "aws", "terraform"]):
            g_type = GapClassificationType.TOOLING_INFRASTRUCTURE_GAP
            remediation_strategy = f"Integrate automated {skill_name} infrastructure pipelines into your primary application codebase."
        else:
            g_type = GapClassificationType.SYNTAX_FRAMEWORK_GAP
            remediation_strategy = f"Implement idiomatic design patterns using {skill_name} and add unit test suites."

        return {
            "skill": skill_name,
            "classification_type": g_type.value,
            "remediation_strategy": remediation_strategy,
            "depth_context": evidence_rec.implementation_depth
        }
