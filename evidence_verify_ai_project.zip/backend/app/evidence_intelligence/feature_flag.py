import os

def is_evidence_engine_enabled() -> bool:
    """
    Checks if the Advanced Evidence Intelligence Engine feature flag is active.
    Defaults to False if not explicitly set to 'true'.
    """
    val = os.getenv("EVIDENCE_ENGINE_ENABLED", "false").strip().lower()
    return val in ["true", "1", "yes", "on"]
