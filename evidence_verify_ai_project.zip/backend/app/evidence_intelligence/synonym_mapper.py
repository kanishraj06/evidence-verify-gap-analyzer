from typing import Dict, List, Set

CANONICAL_SYNONYMS: Dict[str, List[str]] = {
    "kubernetes": ["k8s", "k8s cluster", "kube", "kubectl", "helm", "kubernetes cluster"],
    "docker": ["containerization", "dockerfile", "docker-compose", "docker compose", "containerized"],
    "postgresql": ["postgres", "pgsql", "psql", "postgre sql"],
    "python": ["python3", "py", "cpython"],
    "javascript": ["js", "ecmascript", "es6", "es6+"],
    "typescript": ["ts"],
    "fastapi": ["fast api", "fastapi framework"],
    "react": ["reactjs", "react.js", "react framework"],
    "aws": ["amazon web services", "aws ec2", "aws s3", "aws lambda", "aws ecs", "aws eks"],
    "gcp": ["google cloud", "google cloud platform", "gke", "cloud run"],
    "pytorch": ["torch", "pytorch deep learning"],
    "tensorflow": ["tf", "keras"],
    "scikit-learn": ["sklearn", "scikit learn"],
    "ci/cd": ["cicd", "continuous integration", "continuous deployment", "github actions", "gitlab ci", "jenkins"],
    "git": ["github", "gitlab", "version control", "git branching"],
    "rest api": ["restful api", "rest apis", "restful apis", "openapi", "swagger"],
    "graphql": ["graph ql", "apollo graphql"],
    "redis": ["redis cache", "in-memory cache"],
    "mongodb": ["mongo", "mongodb database"],
    "terraform": ["tf iac", "hashicorp terraform", "infrastructure as code"]
}

class TechSynonymMapper:
    """Maps various technological aliases, abbreviations, and informal references to canonical identifiers."""
    
    def __init__(self):
        self._alias_to_canonical: Dict[str, str] = {}
        for canonical, aliases in CANONICAL_SYNONYMS.items():
            self._alias_to_canonical[canonical.lower()] = canonical
            for alias in aliases:
                self._alias_to_canonical[alias.lower()] = canonical

    def get_canonical_name(self, raw_term: str) -> str:
        clean = raw_term.strip().lower()
        return self._alias_to_canonical.get(clean, raw_term.strip())

    def get_all_aliases(self, canonical_term: str) -> Set[str]:
        c_lower = canonical_term.strip().lower()
        aliases = set(CANONICAL_SYNONYMS.get(c_lower, []))
        aliases.add(c_lower)
        return aliases
