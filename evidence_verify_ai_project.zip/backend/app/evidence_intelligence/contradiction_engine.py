from typing import List, Dict, Any
from ..models.schemas import ResumeStructured, EvidenceRecord, EvidenceStatus

class ContradictionDetectionEngine:
    """Detects resume inconsistencies, unsubstantiated seniority claims, and architectural gaps."""

    def audit_resume_contradictions(
        self,
        resume: ResumeStructured,
        evidence_map: Dict[str, EvidenceRecord]
    ) -> List[Dict[str, str]]:
        findings: List[Dict[str, str]] = []

        # 1. Unsubstantiated claims (listed in skills, absent from projects)
        unsubstantiated = [
            s for s in resume.skills_claimed
            if s.strip().lower() in {k.lower(): v for k, v in evidence_map.items()} and
            evidence_map.get(s, EvidenceRecord(skill_name=s, status=EvidenceStatus.NOT_FOUND, strength_score=0.0, is_claimed=True, summary_verdict="")).status == EvidenceStatus.CLAIMED_UNVERIFIED
        ]
        if unsubstantiated:
            findings.append({
                "category": "Unsubstantiated Skill Claims",
                "severity": "Medium",
                "details": f"{len(unsubstantiated)} skill(s) ({', '.join(unsubstantiated[:4])}) are listed in summary but have zero project evidence."
            })

        # 2. Architecture vs Infrastructure Check
        has_microservices = any("microservices" in s.lower() for s in resume.skills_claimed) or any("microservices" in p.description.lower() for p in resume.projects)
        has_containerization = any("docker" in e.lower() or "kubernetes" in e.lower() for e in evidence_map.keys() if evidence_map[e].status in [EvidenceStatus.STRONGLY_SUPPORTED, EvidenceStatus.SUPPORTED])
        if has_microservices and not has_containerization:
            findings.append({
                "category": "Architectural Discrepancy",
                "severity": "High",
                "details": "Resume claims microservice architecture, but lacks verified containerization (Docker/Kubernetes) evidence."
            })

        return findings
