from typing import Dict, Any, List
from ..models.schemas import EvidenceRecord, EvidenceStatus

class EvidenceMaturityEngine:
    """Evaluates the engineering implementation maturity level of candidate evidence."""

    MATURITY_LEVELS = [
        "Level 0: Nominal / Claimed Only",
        "Level 1: Academic / Sandbox Built",
        "Level 2: Integrated Application",
        "Level 3: Production-Hardened & Scaled"
    ]

    def assess_maturity(self, evidence_rec: EvidenceRecord) -> Dict[str, Any]:
        strength = evidence_rec.strength_score
        status = evidence_rec.status
        depth = evidence_rec.implementation_depth.lower()
        locations_count = len(evidence_rec.evidence_locations)

        if status == EvidenceStatus.STRONGLY_SUPPORTED or "production" in depth:
            level = self.MATURITY_LEVELS[3]
            desc = "Demonstrates high scale, production telemetry, or verifiable deployment metrics."
        elif status == EvidenceStatus.SUPPORTED or locations_count >= 1:
            level = self.MATURITY_LEVELS[2]
            desc = "Directly integrated into working project or employment application stack."
        elif status == EvidenceStatus.PARTIAL:
            level = self.MATURITY_LEVELS[1]
            desc = "Academic or prototype exposure without multi-component integration."
        else:
            level = self.MATURITY_LEVELS[0]
            desc = "Nominal resume mention with zero verifiable implementation artifacts."

        return {
            "skill": evidence_rec.skill_name,
            "maturity_level": level,
            "maturity_score": strength,
            "description": desc
        }
